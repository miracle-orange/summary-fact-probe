"""Audited, format-only recovery for the existing meeting-probe evaluator.

Use beside the unchanged manual_summary_cli.py. No generation output or project
source is edited. A failed match/verify stage gets at most one full-list retry
per invocation, with an explicit count/ID/required-field reminder. Real request
hashes, errors, and responses are retained; no judgments are filled in locally.
"""

from __future__ import annotations

import copy
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path

from meeting_probe import cli
from meeting_probe import evaluate as ev
from meeting_probe.api import ModelResponseError
from meeting_probe.common import canonical_hash, load_json, sha256_file, write_json


def strict_match(output, expected, candidate_count):
    items = output.get("matches")
    if not isinstance(items, list) or len(items) != expected:
        raise ValueError(f"Expected {expected} fact matches")
    for index, item in enumerate(items):
        if not isinstance(item, dict) or not {"fact_idx", "align_unit_idx"} <= item.keys():
            raise ValueError(f"Match item {index} must contain fact_idx and align_unit_idx")
        if type(item["fact_idx"]) is not int or item["fact_idx"] != index:
            raise ValueError("Fact matches must be ordered and complete")
        aligned = item["align_unit_idx"]
        if aligned is not None and (type(aligned) is not int or not 0 <= aligned < candidate_count):
            raise ValueError(f"Invalid align_unit_idx: {aligned!r}")


def strict_verify(output, expected):
    items = output.get("verifications")
    if not isinstance(items, list) or len(items) != expected:
        raise ValueError(f"Expected {expected} verification items")
    for index, item in enumerate(items):
        if not isinstance(item, dict) or not {"fact_idx", "conclusion"} <= item.keys():
            raise ValueError(f"Verification item {index} lacks required fields")
        if type(item["fact_idx"]) is not int or item["fact_idx"] != index:
            raise ValueError("Verifications must be ordered and complete")
        if item["conclusion"] not in {"supported", "not supported"}:
            raise ValueError(f"Invalid conclusion: {item['conclusion']!r}")


def format_request(request, stage):
    marker = "[REFERENCE FACTS]\n" if stage == "match" else "[CLAIMS]\n"
    user = request["user"]
    start = user.index(marker) + len(marker)
    items, _ = json.JSONDecoder().raw_decode(user[start:].lstrip())
    if not isinstance(items, list) or not items:
        raise ValueError("Cannot identify the numbered reference/claim list")
    ids = [item["id"] for item in items]
    if any(type(i) is not int for i in ids) or ids != list(range(len(items))):
        raise ValueError("Input IDs must be zero-based, consecutive and ordered")
    key = "matches" if stage == "match" else "verifications"
    fields = ("Every record must explicitly contain fact_idx and align_unit_idx. "
              "If no candidate qualifies under the original matching rule, return "
              "align_unit_idx: null rather than omitting the record.") if stage == "match" else (
              "Every record must explicitly contain fact_idx and conclusion. "
              "Use only the original supported / not supported labels.")
    reminder = (
        "\n\n[OUTPUT FORMAT CHECK]\n"
        "Keep the original evidence and evaluation criteria unchanged. "
        f"Return exactly {len(ids)} records in {key}. "
        f"The fact_idx values must be {json.dumps(ids)}, exactly once in this order. "
        "Include both the first and last ID; do not omit any input item. "
        f"{fields}\nReturn the complete JSON object, not a patch.\n"
        "[/OUTPUT FORMAT CHECK]"
    )
    result = copy.deepcopy(request)
    result["user"] += reminder
    return result


def valid_record(record, hashes, validator):
    if (not isinstance(record, dict) or record.get("status") != "ok"
            or record.get("request_hash") not in hashes
            or record.get("metadata", {}).get("finish_reason") != "stop"):
        return False
    try:
        validator(record["output"])
    except (KeyError, TypeError, ValueError):
        return False
    return True


def invalid_schema(record, hashes, validator):
    if not isinstance(record, dict) or record.get("request_hash") not in hashes:
        return False
    if record.get("problem") == "invalid_output_json":
        return True
    if (record.get("metadata", {}).get("finish_reason") != "stop"
            or not isinstance(record.get("output"), dict)):
        return False
    try:
        validator(record["output"])
    except (KeyError, TypeError, ValueError):
        return True
    return False


def install(root, snapshot):
    root = root.resolve()
    policy_path = root / "evaluation-format-recovery.json"
    policy = {
        "version": 1,
        "strategy": "one_full_list_format_retry_after_invalid_schema",
        "baseline_snapshot_hash": canonical_hash(snapshot),
        "helper_sha256": sha256_file(Path(__file__).resolve()),
        "judge": snapshot["experiment"]["judge"],
        "stages": ["match", "verify"],
        "local_judgment_imputation": False,
    }
    if policy_path.exists():
        if load_json(policy_path) != policy:
            raise ValueError("Evaluation recovery policy differs; retain the existing script/policy")
    else:
        write_json(policy_path, policy)
    recovery_root = root / "evaluation-format-recovery"
    recovery_root.mkdir(exist_ok=True)
    original = ev._cached_judge
    ev._validate_match = strict_match
    ev._validate_verify = strict_verify

    async def cached(client, cache_path, request, validator):
        stage = cache_path.parent.name
        if stage not in {"match", "verify"}:
            return await original(client, cache_path, request, validator)
        cache_path = cache_path.resolve()
        cache_path.relative_to(root / "evaluation")
        retry = format_request(request, stage)
        base_hash, retry_hash = canonical_hash(request), canonical_hash(retry)
        hashes = {base_hash, retry_hash}
        record = load_json(cache_path) if cache_path.is_file() else None
        if valid_record(record, hashes, validator):
            return record["output"]
        error_path = cache_path.with_suffix(".error.json")
        error = load_json(error_path) if error_path.is_file() else None
        known_bad = invalid_schema(record, hashes, validator) or invalid_schema(error, hashes, validator)
        if not known_bad:
            try:
                return await original(client, cache_path, request, validator)
            except ModelResponseError as exc:
                if exc.kind != "invalid_output_json":
                    raise
            except (KeyError, TypeError, ValueError):
                # Only schema-invalid stored output qualifies, not arbitrary errors.
                latest = load_json(error_path) if error_path.is_file() else None
                if not invalid_schema(latest, hashes, validator):
                    raise
        audit = Path(tempfile.mkdtemp(prefix="attempt-", dir=str(recovery_root)))
        for old in (cache_path, error_path):
            if old.is_file():
                shutil.copyfile(old, audit / old.name)
        write_json(audit / "requests.json", {
            "cache_path": str(cache_path.relative_to(root)),
            "baseline_request": request,
            "baseline_request_hash": base_hash,
            "format_retry_request": retry,
            "format_retry_request_hash": retry_hash,
            "policy_hash": canonical_hash(policy),
        })
        # An invalid cache already using the retry hash must not trap the old
        # cache reader before its HTTP call. Move it into this recoverable audit.
        if record and record.get("request_hash") == retry_hash:
            cache_path.rename(audit / (cache_path.name + ".invalid-cache"))
        print("Format-only retry:", cache_path.relative_to(root), flush=True)
        try:
            output = await original(client, cache_path, retry, validator)
        except Exception:
            if error_path.is_file():
                shutil.copyfile(error_path, audit / "format-retry.error.json")
            raise
        recovered = load_json(cache_path)
        if not valid_record(recovered, {retry_hash}, validator):
            raise ValueError("Format retry did not produce a complete valid response")
        recovered["schema_recovery"] = {
            "baseline_request_hash": base_hash,
            "policy_hash": canonical_hash(policy),
            "audit_path": str(audit.relative_to(root)),
            "scope": "full_list_rejudged_by_same_model",
        }
        write_json(cache_path, recovered)
        shutil.copyfile(cache_path, audit / "format-retry.success.json")
        return output

    ev._cached_judge = cached
    print("Evaluation format recovery:", policy_path, flush=True)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    args = cli.parser().parse_args(argv)
    if args.command not in {"evaluate", "report"}:
        raise ValueError("Use this helper only for evaluate or report")
    root = args.run_dir.resolve()
    snapshot = load_json(root / "protocol-snapshot.json")
    manual_path = root / "manual_summary_cli.py"
    spec = importlib.util.spec_from_file_location("probe_manual_summary_existing", manual_path)
    manual = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(manual)
    manual.configure(args)
    install(root, snapshot)
    return cli.main(argv)


if __name__ == "__main__":
    raise SystemExit(main())