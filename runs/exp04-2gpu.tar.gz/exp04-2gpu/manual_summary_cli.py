"""Run the existing CLI with recorded, sample-wide summary overrides.

No installed project modules are edited. PROBE_FIX_IDS registers samples whose
summary generation has a recorded truncation/JSON failure. All summary arms for
each registered sample use presence_penalty=0.5; extraction is unchanged.
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path

from meeting_probe import cli
from meeting_probe import generate as gen
from meeting_probe.common import (
    PROJECT_ROOT, canonical_hash, load_json, read_jsonl, sha256_file, write_json,
)


def configure(args):
    root = args.run_dir.resolve()
    snapshot = load_json(root / "protocol-snapshot.json")
    assert load_json(args.config) == snapshot["experiment"], "Frozen config changed"
    assert load_json(PROJECT_ROOT / "configs/prompts.json") == snapshot["prompts"], "Frozen prompts changed"
    if hasattr(args, "profile"):
        assert load_json(PROJECT_ROOT / "configs" / f"profile-{args.profile}.json") == snapshot["profile"], "Frozen profile changed"
    rows = {r["sample_id"]: r for r in read_jsonl(args.data)}
    marker = root / "manual-summary-overrides.json"
    base = {
        "version": 1,
        "baseline_snapshot_hash": canonical_hash(snapshot),
        "helper_sha256": sha256_file(Path(__file__).resolve()),
        "data_sha256": sha256_file(args.data),
        "presence_penalty_summary": 0.5,
        "scope": "all_summary_arms_for_registered_samples",
    }
    policy = load_json(marker) if marker.exists() else {**base, "sample_ids": []}
    assert all(policy.get(k) == v for k, v in base.items()), "Override policy differs from this run"
    ids = set(policy["sample_ids"])
    requested = {s.strip() for s in os.environ.get("PROBE_FIX_IDS", "").split(",") if s.strip()}
    assert (ids | requested) <= rows.keys(), "Unknown sample ID"
    sources = {rows[sid]["conversation"] for sid in ids | requested}
    assert all(sid in ids | requested or row["conversation"] not in sources for sid, row in rows.items()), "Another sample has identical source text; do not use a source-based override"
    added = requested - ids
    if added:
        assert args.command == "generate", "Register new samples with generate first"
        for sid in added:
            errors = [root / "generation/summaries" / arm / f"{sid}.error.json" for arm in gen.ARMS]
            assert any(p.is_file() and load_json(p).get("problem") in {"output_truncated", "invalid_output_json"} for p in errors), f"No recorded summary truncation/JSON failure for {sid}"
        audit = Path(tempfile.mkdtemp(prefix="manual-summary-before-", dir=str(root)))
        write_json(audit / "previous-policy.json", policy)
        write_json(audit / "protocol-snapshot.json", snapshot)
        names = {f"{sid}.json" for sid in added} | {f"{sid}.error.json" for sid in added}
        for folder in ("generation", "evaluation", "metrics"):
            for path in (root / folder).rglob("*.json"):
                if path.name in names or any(path.name.endswith(f"-{sid}.json") for sid in added):
                    target = audit / path.relative_to(root)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(path, target)
        ids |= added
        policy["sample_ids"] = sorted(ids)
        write_json(marker, policy)
        print("Previous sample records backed up:", audit, flush=True)
    assert ids, "Set PROBE_FIX_IDS=meeting-1707 to register the failed sample"
    prefixes = tuple(f"[CONVERSATION]\n{rows[sid]['conversation']}\n[/CONVERSATION]" for sid in sorted(ids))
    for sid in ids:
        prefix = f"[CONVERSATION]\n{rows[sid]['conversation']}\n[/CONVERSATION]"
        for name in ("direct", "assisted"):
            assert snapshot["prompts"][name].replace("{{SOURCE}}", rows[sid]["conversation"]).startswith(prefix), "Unexpected summary template"
    original = gen._generation_request

    def request(system, user, generation, max_tokens, *, stage="summary"):
        value = original(system, user, generation, max_tokens, stage=stage)
        if stage == "summary" and user.startswith(prefixes):
            value["extra_body"]["presence_penalty"] = 0.5
        return value

    gen._generation_request = request
    print("Manual summary overrides:", sorted(ids), "presence_penalty=0.5", flush=True)
    print("Override registry:", marker, flush=True)
    return policy


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    args = cli.parser().parse_args(argv)
    assert args.command in {"generate", "check-run", "preflight", "evaluate", "report"}, "Unsupported command"
    configure(args)
    return cli.main(argv)


if __name__ == "__main__":
    raise SystemExit(main())