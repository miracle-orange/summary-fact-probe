# Generic meeting fact-intervention report

## Summary metrics (macro average)

| Arm | N | Completeness | Conciseness | Faithfulness |
|---|---:|---:|---:|---:|
| direct_s | 300 | 0.3825 | 0.6262 | 0.9751 |
| direct_l | 300 | 0.4583 | 0.6676 | 0.9778 |
| s_to_s | 300 | 0.5505 | 0.6684 | 0.9620 |
| s_to_l | 300 | 0.5666 | 0.7017 | 0.9573 |
| l_to_s | 300 | 0.6157 | 0.6518 | 0.9677 |
| l_to_l | 300 | 0.6415 | 0.6933 | 0.9650 |
| gold_to_s | 300 | 0.7552 | 0.8708 | 0.9656 |
| gold_to_l | 300 | 0.8063 | 0.8658 | 0.9687 |

## Paired contrasts

Percentile bootstrap intervals use 2000 paired resamples.

| Contrast | Metric | N | Difference | CI |
|---|---|---:|---:|---:|
| direct_l - direct_s | completeness | 300 | 0.0759 | [0.0522, 0.0991] |
| direct_l - direct_s | conciseness | 300 | 0.0413 | [0.0120, 0.0698] |
| direct_l - direct_s | faithfulness | 300 | 0.0027 | [-0.0033, 0.0088] |
| s_to_s - direct_s | completeness | 300 | 0.1680 | [0.1412, 0.1951] |
| s_to_s - direct_s | conciseness | 300 | 0.0421 | [0.0140, 0.0719] |
| s_to_s - direct_s | faithfulness | 300 | -0.0130 | [-0.0193, -0.0067] |
| l_to_s - s_to_s | completeness | 300 | 0.0652 | [0.0441, 0.0863] |
| l_to_s - s_to_s | conciseness | 300 | -0.0166 | [-0.0375, 0.0040] |
| l_to_s - s_to_s | faithfulness | 300 | 0.0056 | [-0.0005, 0.0117] |
| l_to_s - direct_s | completeness | 300 | 0.2332 | [0.2051, 0.2605] |
| l_to_s - direct_s | conciseness | 300 | 0.0256 | [-0.0035, 0.0564] |
| l_to_s - direct_s | faithfulness | 300 | -0.0074 | [-0.0133, -0.0013] |
| gold_to_l - gold_to_s | completeness | 300 | 0.0512 | [0.0338, 0.0694] |
| gold_to_l - gold_to_s | conciseness | 300 | -0.0050 | [-0.0187, 0.0101] |
| gold_to_l - gold_to_s | faithfulness | 300 | 0.0031 | [-0.0031, 0.0099] |
| s_to_l - l_to_l | completeness | 300 | -0.0749 | [-0.0941, -0.0566] |
| s_to_l - l_to_l | conciseness | 300 | 0.0084 | [-0.0083, 0.0251] |
| s_to_l - l_to_l | faithfulness | 300 | -0.0077 | [-0.0146, -0.0009] |

These are diagnostic associations under fact-list intervention. They do not by themselves prove that fact selection explains the entire model-scale gap.
