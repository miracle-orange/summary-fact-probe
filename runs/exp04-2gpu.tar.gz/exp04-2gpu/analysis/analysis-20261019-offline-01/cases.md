# 正反个例（按预定规则抽取）

选择规则：以逐样本 completeness 的 C-B 从高到低/低到高排序，各取 5 例；先贪心覆盖不同来源，再按排序补足，sample_id 作确定性并列排序。参考事实及纪要句子来自既有数据/生成缓存，覆盖判断来自既有 match 缓存；未进行新评审。

正向案例的 C-B 以 0-1 比例表示；表中指标也为 0-1。证据摘录只呈现与案例差异相关的短文本。

## C-B最正向案例

### meeting-0892 | QMSum-Academic | C-B=0.6471

gold事实数 17；small覆盖/支持/事实数 0.235/1.000/10；large 0.706/0.950/20。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.1176 | 0.2000 | 1.0000 |
| s_to_l | 0.0000 | 0.0000 | 1.0000 |
| l_to_s | 0.6471 | 0.4737 | 0.9706 |
| l_to_l | 0.5294 | 0.7000 | 1.0000 |

关键参考事实与保留情况：
- gold[0] PhD C used an HMM-based Munich system with Gaussian mixtures to detect speech and non-speech portions in mixed files.；原文摘录：“isfmarker} to detect s speech or nonspeech {pause} portions in that .
Professor G: Mm - hmm .
PhD C: And what I did so far is I just used our old Munich system , which is an HMM - ba based system with Gaussian mixtures for s speech and nonspeech . And it was a system which used o”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[2] PhD C added multi-mixture possibilities to distinguish between loud and quiet speakers.；原文摘录：“m , for those in which there {nonvocalsound} was , uh , quiet speakers in the mix .
PhD C: Yeah . Uh , yeah . That {disfmarker} that was one {disfmarker} one {disfmarker} one thing , uh , why I added more mixtures for {disfmarker} for the speech . So I saw that there were loud {d”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[3] The transcribers consider the new non-speech/speech pre-segmentation of the signal a significant improvement.；原文摘录：“forward in terms of the nonspeech - speech pre - segmenting of the signal .
Professor G: OK .
Grad A: Well , we have steps forward .
PhD C: Yeah .
Postdoc F: Well , it 's a {disfmarker} it 's a big improvement .
PhD C: I would prefer this .
Professor G: Yes . Yeah , well . OK . U”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/False。

- s_to_s 纪要保留证据：未保留上述差异事实。
- s_to_l 纪要保留证据：未保留上述差异事实。
- l_to_s 纪要保留证据：gold[0]→“They have enhanced the system by incorporating multiple Gaussian mixtures for loud and quiet speakers, significantly improving the transcription process.”；gold[2]→“They have enhanced the system by incorporating multiple Gaussian mixtures for loud and quiet speakers, significantly improving the transcription process.”；gold[3]→“The group is discussing progress and challenges in speech transcription efforts, focusing on improving the detection of speech and nonspeech segments.”
- l_to_l 纪要保留证据：gold[0]→“An HMM-Gaussian mixture system was enhanced by adding multiple mixtures for loud and quiet speakers, resulting in significant time savings for transcribers.”；gold[2]→“An HMM-Gaussian mixture system was enhanced by adding multiple mixtures for loud and quiet speakers, resulting in significant time savings for transcribers.”

### meeting-0582 | QMSum-Product | C-B=0.5000

gold事实数 16；small覆盖/支持/事实数 0.500/0.833/6；large 0.812/0.722/18。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.4375 | 0.6667 | 0.9286 |
| s_to_l | 0.3750 | 0.5714 | 0.9355 |
| l_to_s | 0.8750 | 0.6000 | 0.9394 |
| l_to_l | 0.5000 | 0.8750 | 0.8846 |

关键参考事实与保留情况：
- gold[3] The prototype includes rubber grips to address the user requirement for a spongy feel.；原文摘录：“ok-and-feel . It was twice as important as anything else . Um they liked fruit and vegetables in the new styles . Um and a spongy feel . So we were talking about trying to incorporate those into our prototype . Um they wanted limited buttons and simplicity . Um then we looked at”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[4] The team evaluates the prototype based on criteria derived from previous user complaints.；原文摘录：“. Just based on the past trend reports that I was looking at earlier . And then we'll do a group evaluation of the prototype . And then we will calculate the average score to see how we did . Um so the criteria we're gonna be looking at are the complaints um that we heard from th”；S覆盖=True，L覆盖=True；A/B/C/D保留=False/False/True/False。
- gold[5] The team assigns a score of one to the prototype for simplicity and intuitiveness.；原文摘录：“. Just based on the past trend reports that I was looking at earlier . And then we'll do a group evaluation of the prototype . And then we will calculate the average score to see how we did . Um so the criteria we're gonna be looking at are the complaints um that we heard from th”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/False。

- s_to_s 纪要保留证据：未保留上述差异事实。
- s_to_l 纪要保留证据：未保留上述差异事实。
- l_to_s 纪要保留证据：gold[3]→“The remote uses a plastic case with rubber grips for ergonomics and is powered by two batteries.”；gold[4]→“During an evaluation, the team scored their performance at 2.4285 on a 7-point scale, addressing criteria such as solving user complaints about appearance, simplicity, controllability, and technological innovation.”；gold[5]→“During an evaluation, the team scored their performance at 2.4285 on a 7-point scale, addressing criteria such as solving user complaints about appearance, simplicity, controllability, and technological innovation.”
- l_to_l 纪要保留证据：gold[3]→“While the remote's ergonomic design with rubber grips and innovative form received positive feedback, the bright yellow color was divisive.”

### meeting-0559 | ECTSum | C-B=0.4348

gold事实数 23；small覆盖/支持/事实数 0.739/1.000/37；large 0.870/1.000/37。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.4348 | 0.6364 | 1.0000 |
| s_to_l | 0.4348 | 0.5714 | 1.0000 |
| l_to_s | 0.8696 | 0.5429 | 1.0000 |
| l_to_l | 0.6522 | 0.6429 | 1.0000 |

关键参考事实与保留情况：
- gold[1] Macerich's December 2020 sales approached 85% of pre-COVID levels.；原文摘录：“luding restaurant dining and going to the mall.
Our shoppers have returned.
In fact, December sales were approaching 85% of pre-COVID levels even in the midst of a surge in COVID cases.
Gradually, restrictions on capacity and indoor dining are being lifted, and that will help bot”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[2] Macerich's occupancy level stood at 90% at the end of 2020.；原文摘录：“a result, our collections continued to improve.
As of today, collection rates increased to 89% in the third quarter and 92% in the fourth quarter of 2020.
Occupancy at the end of the third quarter was 89.7%, that's down 110 basis points from last quarter and down 4.3% from a yea”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/False。
- gold[4] Of Macerich's 27 JCPenney locations, only two locations closed in 2020.；原文摘录：“ecovery post-COVID.
We have worked through most of the bankruptcies from 2020.
And fortunately, the vast majority of those have been reorganizations, not liquidations.
The biggest bankruptcy of the year was JCPenney.
Of our 27 JCPenney locations, only two locations closed, Green”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/False。
- gold[5] Macerich achieved the Number 1 Global Real Estate Sustainability Benchmark Ranking in the North American retail sector for the sixth consecutive year.；原文摘录：“s a leader in sustainability and have achieved the No.
1 Global Real Estate Sustainability Benchmark Ranking in the North American retail sector.
That makes six straight years for that honor.
Highlights of the financial results for the quarter are as follows.
Funds from operation”；S覆盖=True，L覆盖=False；A/B/C/D保留=True/True/False/False。

- s_to_s 纪要保留证据：gold[5]→“1 Global Real Estate Sustainability Benchmark Ranking for six consecutive years.”
- s_to_l 纪要保留证据：gold[5]→“1 Global Real Estate Sustainability Benchmark Ranking in North America for six consecutive years.”
- l_to_s 纪要保留证据：gold[1]→“Despite challenges, December 2020 sales approached 85% of pre-COVID levels.”；gold[2]→“The company's occupancy level reached 90%, the lowest since the GFC, but is expected to recover within two years.”；gold[4]→“Only two JCPenney locations closed, and both leases are now out for signature.”
- l_to_l 纪要保留证据：gold[1]→“Rent collections improved dramatically from 35% in April and May to 92% in the fourth quarter of 2020, with December sales reaching around 85% of pre-pandemic levels.”

### meeting-0791 | QMSum-Committee | C-B=0.4211

gold事实数 19；small覆盖/支持/事实数 0.211/1.000/2；large 0.579/1.000/17。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.5263 | 0.8571 | 1.0000 |
| s_to_l | 0.2632 | 0.4286 | 1.0000 |
| l_to_s | 0.6842 | 0.6667 | 1.0000 |
| l_to_l | 0.4737 | 0.4167 | 1.0000 |

关键参考事实与保留情况：
- gold[0] All schools in Wales will close for statutory education provision due to the coronavirus pandemic.；原文摘录：“miss out on any education, unless absolutely necessary. So, the decision to close all schools from tomorrow for statutory education provision was not taken lightly, but I believe it was necessary, given the advice and recommendations that we had received from a public health pers”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[3] All maintained schools in Wales have access to the Hwb digital learning platform to support distance learning.；原文摘录：“ning needs. I can confirm that all maintained schools in Wales already have access to a range of digital tools that can support distance learning through the world-class Hwb digital learning platform, including virtual classrooms and video-conferencing facilities. A guide on what”；S覆盖=False，L覆盖=True；A/B/C/D保留=True/False/True/True。
- gold[6] Schools in Wales are working with local authorities to identify children of key workers, such as health workers.；原文摘录：“next two days will have been able to identify, at least at the earlier stage, in terms of health workers, the type and numbers of people. There are already schools who have informed us, and local authorities, of their plans for these activities to be starting next week, which is”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。

- s_to_s 纪要保留证据：gold[3]→“The Welsh Government emphasized the use of digital tools like the Hwb platform for distance learning and highlighted the importance of maintaining continuity of education.”
- s_to_l 纪要保留证据：未保留上述差异事实。
- l_to_s 纪要保留证据：gold[0]→“The Welsh Government, led by Minister Kirsty Williams, announced the closure of all schools in Wales due to the coronavirus pandemic, emphasizing the need to prioritize public health while ensuring continuity of education.”；gold[3]→“Digital learning tools, such as the Hwb platform, will support distance learning, and a guide has been developed to assist schools.”；gold[6]→“Headteachers and staff will remain in schools next week to plan for the new purpose, with local authorities developing emergency provisions for food and care.”
- l_to_l 纪要保留证据：gold[0]→“The Welsh Government has decided to close all schools in Wales due to the coronavirus pandemic, effective from the following day, with a new focus on supporting vulnerable children, children of key workers (such as healthcare professionals)”；gold[3]→“Digital learning tools, including the Hwb platform, will facilitate distance learning, and summer exams have been cancelled.”；gold[6]→“The Welsh Government has decided to close all schools in Wales due to the coronavirus pandemic, effective from the following day, with a new focus on supporting vulnerable children, children of key workers (such as healthcare professionals)”

### meeting-1282 | MeetingBank | C-B=0.3333

gold事实数 12；small覆盖/支持/事实数 0.583/1.000/16；large 0.833/1.000/22。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.5000 | 0.3333 | 1.0000 |
| s_to_l | 0.4167 | 0.4444 | 0.9259 |
| l_to_s | 0.7500 | 0.3636 | 1.0000 |
| l_to_l | 0.7500 | 0.4615 | 1.0000 |

关键参考事实与保留情况：
- gold[1] Long Beach's 1988 granny flat ordinance was deemed null and void due to non-compliance with new state legislation.；原文摘录：“he code. And if everything is good, there's approved with no discretion. Long Beach is existing 1988. A granny flat ordinance was deemed null and void because it was no longer in compliance with the new state legislation. And then until adoption of a new local ordinance, only sta”；S覆盖=True，L覆盖=True；A/B/C/D保留=True/False/True/True。
- gold[3] The proposed Long Beach ordinance prohibits Accessory Dwelling Units from being used for short-term rentals of less than 30 days.；原文摘录：“g used for short term rentals. But I would love some a little bit more clarification for my benefit, as well as the Publix over the limited accessory accessory dwelling units versus conforming. What what what is that? Sure. So there are two categories of accessory dwelling units.”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[4] The proposed ordinance requires covenants ensuring the property is owner-occupied and the Accessory Dwelling Unit cannot be sold separately from the primary dwelling.；原文摘录：“ns intact, covenants are required for properties. Proposing an ADU covenants would require that the property be owner occupied, that the 80 you cannot be sold separately from the primary dwelling, that there is continued availability of the on site parking that is required prohib”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[10] The amended ordinance is scheduled to return to the City Council for a first reading in approximately 30 days.；原文摘录：“7-136 Declare ordinance amending various sections of Title 21 of the Long Beach Municipal Code relating to accessory dwelling units. Read for the first time and lead over to the next regular meeting of the City Council for Final Reading. Adopt a resolution directing the Director”；S覆盖=True，L覆盖=False；A/B/C/D保留=True/True/False/False。

- s_to_s 纪要保留证据：gold[1]→“The existing 1988 granny flat ordinance is deemed null and void due to non-compliance with new state legislation.”；gold[10]→“The city attorney confirmed that the proposed amendments would require updating the documents and bringing the ordinance back for first reading after adjustments.”
- s_to_l 纪要保留证据：gold[10]→“The city attorney noted that the revised ordinance would need to be updated and returned for first reading after incorporating the amendments.”
- l_to_s 纪要保留证据：gold[1]→“The 1988 'granny flat' ordinance was invalidated due to non-compliance with updated state legislation, necessitating a new local framework.”；gold[3]→“Covenants are proposed to ensure owner occupancy, prohibit short-term rentals, and maintain neighborhood character.”；gold[4]→“Covenants are proposed to ensure owner occupancy, prohibit short-term rentals, and maintain neighborhood character.”
- l_to_l 纪要保留证据：gold[1]→“The current 1988 granny flat ordinance was invalidated due to non-compliance with updated state regulations, necessitating a new local ordinance.”；gold[3]→“Replacement parking must be provided if a garage is converted into an ADU, and covenants will ensure owner occupancy, no separate sale of the ADU, and prohibit short-term rentals.”；gold[4]→“Replacement parking must be provided if a garage is converted into an ADU, and covenants will ensure owner occupancy, no separate sale of the ADU, and prohibit short-term rentals.”

## C-B最负向案例

### meeting-0341 | MeetingBank | C-B=-0.4500

gold事实数 20；small覆盖/支持/事实数 0.650/0.794/34；large 0.700/0.978/45。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.5000 | 0.6364 | 1.0000 |
| s_to_l | 0.7000 | 0.8333 | 1.0000 |
| l_to_s | 0.2500 | 0.4444 | 0.9762 |
| l_to_l | 0.4000 | 0.4545 | 0.9623 |

关键参考事实与保留情况：
- gold[0] Denver City Council Bills 20-0333 and 20-0352 concern the rezoning of the property at 3001 South Federal Boulevard, commonly known as Loretto Heights.；原文摘录：“Joe Moore and good evening. Members of Council Jason Morrison, senior city planner with Community Planning and Development. I'm here to present the rezoning application at 3001 South Federal Boulevard, or the property more commonly known as Loretto Heights. The request is from M”；S覆盖=False，L覆盖=True；A/B/C/D保留=True/True/False/True。
- gold[4] The rezoning application requests changing the zoning to PUD-G 24, PUD-G 25, and U-MX-3 with waivers.；原文摘录：“rdable housing. And the application identifies change or changing conditions as justifying circumstance with the newly adopted plan guidance in the recently adopted the red light small area plan. The requested Pdg 24, pdg 25 and you three with waivers is consistent with the neigh”；S覆盖=False，L覆盖=True；A/B/C/D保留=True/True/False/False。
- gold[5] The proposed PUD-G 24 zone district applies to the historic core of the Loretto Heights campus to facilitate preservation and adaptive reuse.；原文摘录：“this one that include a historic preservation component as well as a customized zoning approach. The proposed G 24 would promote the preservation and adaptive reuse of the historic resources on the former Loreto Heights campus and would facilitate its continued use consistent wi”；S覆盖=True，L覆盖=True；A/B/C/D保留=True/True/False/False。

- s_to_s 纪要保留证据：gold[0]→“The conversation revolves around a public hearing for the rezoning of the former Loreto Heights campus in southwest Denver, presented by Jason Morrison, Senior City Planner with Community Planning and Development.”；gold[4]→“The proposed rezoning includes three zones: DG 24, DG 25, and UN X Three with waivers.”；gold[5]→“DG 24 focuses on the historic core of the campus, emphasizing preservation and adaptive reuse of historic buildings, while DG 25 targets low-scale residential development near open spaces.”
- s_to_l 纪要保留证据：gold[0]→“The Denver City Council conducted a public hearing regarding the rezoning application for the former Loretto Heights campus, located in Council District 2.”；gold[4]→“The proposal involves rezoning the property into three distinct zones—DG 24, DG 25, and UN X Three with waivers—to facilitate a sensitive redevelopment that preserves the site’s historic legacy and meets the needs of the surrounding communi”；gold[5]→“DG 24 focuses on the preservation and adaptive reuse of historic structures and open spaces, while DG 25 allows for low-scale residential development oriented towards new streets and open spaces.”
- l_to_s 纪要保留证据：未保留上述差异事实。
- l_to_l 纪要保留证据：gold[0]→“The Denver City Council is conducting a combined public hearing for Council Bill 20 1-0333 and Council Bill 352, both related to the rezoning of the former Loretto Heights campus located in Southwest Denver, within Council District 2 and th”

### meeting-0378 | QMSum-Academic | C-B=-0.4286

gold事实数 14；small覆盖/支持/事实数 0.500/1.000/18；large 0.643/1.000/10。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.3571 | 0.3636 | 0.9412 |
| s_to_l | 1.0000 | 0.6923 | 0.8500 |
| l_to_s | 0.5714 | 0.7000 | 0.9615 |
| l_to_l | 0.5714 | 0.6667 | 0.9630 |

关键参考事实与保留情况：
- gold[2] A neural network trained on a large database containing multiple languages and noise types performs better than a network trained only on French, Spanish, and English.；原文摘录：“n we started to work on a large dat database containing , uh , sentences from the French , from the Spanish , from the TIMIT , from SPINE , uh from {comment} uh English digits , and from Italian digits . So this is the {disfmarker} another line {disfmarker} another set of lines i”；S覆盖=True，L覆盖=False；A/B/C/D保留=False/True/False/False。
- gold[3] MSG features perform as well as PLP features on the TI-digits task.；原文摘录：“look at the table , the huge table , um , we see that for TI - digits MSG perform as well as the PLP ,
Professor D: Mm - hmm .
PhD A: but this is not the case for Italian what {disfmarker} where the error rate is c is almost uh twice the error rate of PLP .
Professor D: Mm - hmm”；S覆盖=False，L覆盖=False；A/B/C/D保留=False/True/False/False。
- gold[7] Adding Viterbi-aligned French and Spanish data to the Multi-English training set decreases performance compared to using the Multi-English set alone.；原文摘录：“when we use the large training set using French , Spanish , and English , you have one hundred and six without delta and eighty - nine with the delta .
Professor D: a And again all of these numbers are with a hundred percent being , uh , the baseline performance ,
PhD A: Yeah , o”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/True/False/True。

- s_to_s 纪要保留证据：未保留上述差异事实。
- s_to_l 纪要保留证据：gold[2]→“Training on a larger, diverse dataset (French, Spanish, TIMIT, SPINE, etc.)”；gold[3]→“PLP and mel cepstra features were found to perform similarly, but adding MSG features did not lead to significant improvements, likely due to processing issues such as missing filters or DC offsets.”；gold[7]→“Training on a larger, diverse dataset (French, Spanish, TIMIT, SPINE, etc.)”
- l_to_s 纪要保留证据：未保留上述差异事实。
- l_to_l 纪要保留证据：gold[7]→“The multi-English training set (based on TIMIT) outperformed training sets with French or Spanish data for most tasks, likely due to better data quality and alignment.”

### meeting-1322 | QMSum-Committee | C-B=-0.4000

gold事实数 25；small覆盖/支持/事实数 0.120/1.000/2；large 0.600/0.963/27。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.5200 | 0.5556 | 0.9655 |
| s_to_l | 0.6400 | 0.9091 | 1.0000 |
| l_to_s | 0.2400 | 0.6250 | 0.9130 |
| l_to_l | 0.4800 | 0.6667 | 0.8750 |

关键参考事实与保留情况：
- gold[6] The Welsh Government is considering greater flexibility in Pupil Development Grant eligibility, potentially looking at an 'Ever 2' concept.；原文摘录：“to questions, and the first questions are from Llyr Gruffydd.
Llyr Gruffydd AM: Bore da. I just want to start by asking some questions around the targeting of the pupil development grant because, clearly, we've had a lot of evidence around this apparent blurring of eligibility to”；S覆盖=False，L覆盖=True；A/B/C/D保留=True/False/True/True。
- gold[24] The Welsh Government is considering developing a specific Welsh toolkit for evidence-based school interventions.；原文摘录：“t can be recommended to schools.
Kirsty Williams AM: That's not something we're actively looking at. I am actively looking at developing a Welsh toolkit around good practice, evidence base and research. At the moment we use the Sutton Trust toolkit, which is fine and excellent, b”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/False。
- gold[0] Individual Pupil Development Grant interventions must be targeted specifically at children eligible for free school meals.；原文摘录：“that when it comes to individual interventions, those individual interventions should only be targeted at those children who are eligible for free school meals. But in some cases, schools may use their PDG funding to provide a universal intervention, but we would want to—in chal”；S覆盖=True，L覆盖=True；A/B/C/D保留=True/True/False/True。
- gold[1] Schools may use Pupil Development Grant funding for universal interventions if there is evidence of a disproportionate positive effect on outcomes for children eligible for free school meals.；原文摘录：“that when it comes to individual interventions, those individual interventions should only be targeted at those children who are eligible for free school meals. But in some cases, schools may use their PDG funding to provide a universal intervention, but we would want to—in chal”；S覆盖=True，L覆盖=True；A/B/C/D保留=True/True/False/True。
- gold[9] There is a gap in school attendance rates between pupils eligible for free school meals and those who are not eligible.；原文摘录：“focused on low-attaining frees—pupils who are eligible for free school meals.
Kirsty Williams AM: Thank you, Llyr. I think it's important to be absolutely clear that when it comes to individual interventions, those individual interventions should only be targeted at those childre”；S覆盖=False，L覆盖=True；A/B/C/D保留=True/True/False/True。

- s_to_s 纪要保留证据：gold[6]→“She highlights the importance of using PDG for more able and talented children to support their aspirations and discusses the need for more flexibility in eligibility criteria, such as considering a broader timeframe rather than a single po”；gold[0]→“The Cabinet Secretary for Education, Kirsty Williams, emphasizes that PDG should be used to target children eligible for free school meals, while acknowledging that some universal interventions may disproportionately benefit these pupils.”；gold[1]→“The Cabinet Secretary for Education, Kirsty Williams, emphasizes that PDG should be used to target children eligible for free school meals, while acknowledging that some universal interventions may disproportionately benefit these pupils.”；gold[9]→“The discussion also covers the impact of PDG on attendance, exclusion rates, and attainment, with Williams noting that while the attainment gap for free school meal pupils has widened in 2017, there has been a narrowing trend over the years”
- s_to_l 纪要保留证据：gold[0]→“The Cabinet Secretary, Kirsty Williams, clarifies that while PDG is primarily for children eligible for free school meals (FSM), schools can also use it for universal interventions that disproportionately benefit FSM pupils.”；gold[1]→“The Cabinet Secretary, Kirsty Williams, clarifies that while PDG is primarily for children eligible for free school meals (FSM), schools can also use it for universal interventions that disproportionately benefit FSM pupils.”；gold[9]→“Discussions also explored the PDG’s impact on attendance, exclusion rates, and attainment gaps, with specific attention to vulnerable groups such as looked-after and adopted children.”
- l_to_s 纪要保留证据：gold[6]→“Concerns were raised about the current reliance on FSM eligibility as a proxy for identifying disadvantaged pupils, and discussions were held about the possibility of adopting a more flexible system, such as an 'Ever 2' approach, due to res”；gold[24]→“The Welsh Government is also considering alternative performance measures beyond the level 2 plus metric, as well as developing a Welsh toolkit for evidence-based practice to support schools.”
- l_to_l 纪要保留证据：gold[6]→“Flexibility in PDG allocation is under consideration, with a preference for an 'Ever 2' system over 'Ever 6' due to funding constraints.”；gold[0]→“Cabinet Secretary Kirsty Williams confirmed that PDG should primarily target free school meal (FSM)-eligible students, but can also be used for universal interventions that disproportionately benefit them.”；gold[1]→“Cabinet Secretary Kirsty Williams confirmed that PDG should primarily target free school meal (FSM)-eligible students, but can also be used for universal interventions that disproportionately benefit them.”；gold[9]→“Concerns were raised about the effectiveness of PDG in addressing attendance gaps and exclusion rates for FSM and looked-after children, with a call for a cross-governmental approach involving education, health, and social services.”

### meeting-1563 | ECTSum | C-B=-0.3125

gold事实数 32；small覆盖/支持/事实数 0.500/1.000/22；large 0.750/1.000/38。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.4375 | 0.6316 | 0.9796 |
| s_to_l | 0.5312 | 0.7692 | 1.0000 |
| l_to_s | 0.2188 | 0.5000 | 1.0000 |
| l_to_l | 0.6562 | 0.7000 | 1.0000 |

关键参考事实与保留情况：
- gold[6] Big Lots' seasonal category comparable sales increased over 30% on a two-year basis in the third quarter.；原文摘录：“2019, as generally being the most relevant given the abnormal impacts of COVID-19 on our business in 2020.
On a two-year basis, Q3 comparable sales increased 12%, while declining 5% to 2020.
Total sales increased over 14% [Phonetic] versus 2019 with 210 basis points of favorabil”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[7] Big Lots' furniture category comparable sales increased low double digits on a two-year basis in the third quarter.；原文摘录：“ootage in conjunction with our pantry optimization reset last fall.
Furniture delivered another very strong quarter with two-year comps up low double digits.
Seasonal though was the quarter highlight with comps over 30% on a two-year basis with lawn and garden and Halloween and H”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/False/True/True。
- gold[15] Big Lots plans to launch a 'Lots under $5' offering in the middle of 2022.；原文摘录：“ales impact and we plan to complete our rollout in '22.
In addition to these strategies, new initiatives such as Lots under $5 offering represents a further opportunity to drive higher productivity.
The Lots under $5 which will roll out in the middle of 2022 will create a value d”；S覆盖=False，L覆盖=True；A/B/C/D保留=True/False/True/True。
- gold[4] Big Lots' total third-quarter sales increased over 14% compared to 2019.；原文摘录：“oliday season.
Be safe, stay healthy and stop into your local Big Lots for you gifts, decorations, special treats and supplies.
Net sales for the quarter were $1.336 billion, a 3.1% decrease compared to $1.378 billion a year ago, but up 14.4% to the third quarter of 2019.
The dec”；S覆盖=True，L覆盖=True；A/B/C/D保留=True/True/False/True。
- gold[5] Big Lots' third-quarter sales benefited from growth in basket size and average unit retail expansion.；原文摘录：“ontain these for the quarter.
Sales for the quarter benefited from growth in basket, driven by AUR expansion across each category and positive mix effects as we penetrated deeper end of furniture and seasonal.
We saw strong positive two-year comps in Furniture, Seasonal, Soft Hom”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/True/False/True。
- gold[9] Big Lots' rewards program active members increased over 9% year-over-year to 22.1 million members.；原文摘录：“ays incredible value.
The campaign, coupled with our rewards program is resonating.
Rewards active members were up over 9% versus Q3 last year.
Now with 22.1 million members still boasting a five-year CAGAR of 10%.
In Q3, rewards members accounted for 64% of transactions and 76%”；S覆盖=True，L覆盖=True；A/B/C/D保留=True/True/False/True。

- s_to_s 纪要保留证据：gold[15]→“The company is also launching a new initiative called Lots under $5, which will roll out in the middle of 2022, creating a value destination for customers.”；gold[4]→“The company reported third-quarter net sales of $1.336 billion, a 3.1% decrease compared to the same period last year but a 14.4% increase compared to the third quarter of 2019.”；gold[9]→“The company's rewards program is showing growth, with active members up over 9% versus Q3 last year, reaching 22.1 million members with a five-year CAGR of 10%.”
- s_to_l 纪要保留证据：gold[4]→“Big Lots delivered Q3 results in line with guidance despite supply chain disruptions, reporting net sales of $1.336 billion, a 3.1% decrease compared to the prior year but a 14.4% increase compared to 2019.”；gold[5]→“On a two-year basis, Q3 comparable sales rose 12%, driven by basket size and AUR expansion.”；gold[9]→“Rewards members grew by over 9% year-over-year, contributing 64% of transactions and 76% of sales.”
- l_to_s 纪要保留证据：gold[6]→“Key categories like furniture and seasonal showed strong performance, with furniture up low double digits and seasonal exceeding 30% growth.”；gold[7]→“Key categories like furniture and seasonal showed strong performance, with furniture up low double digits and seasonal exceeding 30% growth.”；gold[15]→“The company is also investing in new initiatives like the 'Lots under $5' program, expanding its e-commerce capabilities, and upgrading its distribution centers to enhance efficiency and capacity.”
- l_to_l 纪要保留证据：gold[6]→“Furniture delivered low double-digit two-year comps, and seasonal sales surged over 30%.”；gold[7]→“Furniture delivered low double-digit two-year comps, and seasonal sales surged over 30%.”；gold[15]→“The 'Lots under $5' initiative will launch in mid-2022 to enhance productivity through value-priced items.”；gold[4]→“On a two-year basis, Q3 comparable sales increased by 12%, with total sales rising over 14% compared to 2019, aided by 210 basis points of favorability from new and relocated stores.”；gold[5]→“The growth in basket size was driven by AUR expansion and a positive mix effect, especially in furniture and seasonal categories.”；gold[9]→“The be a BIGionaire brand campaign has been successful, with rewards active members up over 9% year-over-year and rewards members accounting for 64% of transactions and 76% of sales in Q3.”

### meeting-1681 | QMSum-Product | C-B=-0.2857

gold事实数 14；small覆盖/支持/事实数 0.500/0.857/7；large 0.857/1.000/10。

| 组 | 完整性 | 简洁性 | 忠实性 |
| --- | --- | --- | --- |
| s_to_s | 0.5714 | 0.6667 | 1.0000 |
| s_to_l | 0.8571 | 0.7500 | 1.0000 |
| l_to_s | 0.5714 | 1.0000 | 1.0000 |
| l_to_l | 0.5714 | 0.6667 | 1.0000 |

关键参考事实与保留情况：
- gold[7] The team members practiced using the meeting room whiteboard by drawing animals.；原文摘录：“} to make {disfmarker} to to be used to the tools uh available in this nice and smart meeting room we have here . Um then we'll go to uh the plans for project and have general discussions about it . So , the goal of this project is to uh developed a new remote control . Um it sho”；S覆盖=False，L覆盖=True；A/B/C/D保留=True/False/True/True。
- gold[0] Sebastian is the Project Manager.；原文摘录：“so I will be uh Sebastian the Project Manager . Um you are the {disfmarker}
User Interface: I'm uh Michael . I'm the user interface designer .
Project Manager: Okay .
Marketing: Hi I'm Guillermo {gap} . I'm the Marketing Expert .
Industrial Designer: And I am Hemant , the industr”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/True/False/False。
- gold[1] Michael is the User Interface Designer.；原文摘录：“Project Manager: Thanks .
Industrial Designer: Thanks .
User Interface: Alright .”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/True/False/False。
- gold[2] Guillermo is the Marketing Expert.；原文摘录：“so I will be uh Sebastian the Project Manager . Um you are the {disfmarker}
User Interface: I'm uh Michael . I'm the user interface designer .
Project Manager: Okay .
Marketing: Hi I'm Guillermo {gap} . I'm the Marketing Expert .
Industrial Designer: And I am Hemant , the industr”；S覆盖=False，L覆盖=True；A/B/C/D保留=False/True/False/False。

- s_to_s 纪要保留证据：gold[7]→“The team discussed the tools available in the meeting room, particularly the whiteboard, and began drawing their favorite animals.”
- s_to_l 纪要保留证据：gold[0]→“The meeting began with introductions of the participants: Sebastian (Project Manager), Michael (User Interface Designer), Guillermo (Marketing Expert), and Hemant (Industrial Designer).”；gold[1]→“The meeting began with introductions of the participants: Sebastian (Project Manager), Michael (User Interface Designer), Guillermo (Marketing Expert), and Hemant (Industrial Designer).”；gold[2]→“The meeting began with introductions of the participants: Sebastian (Project Manager), Michael (User Interface Designer), Guillermo (Marketing Expert), and Hemant (Industrial Designer).”
- l_to_s 纪要保留证据：gold[7]→“As an icebreaker, the team drew animals on a whiteboard; Michael, the User Interface Designer, drew a spider, while Guillermo, the Marketing Expert, mentioned wanting to draw a panther, and Hemant, the Industrial Designer, decided to draw a”
- l_to_l 纪要保留证据：gold[7]→“To familiarize themselves with the tools in the meeting room, the team participated in an icebreaker activity where they drew animals on the whiteboard, sharing brief descriptions of their chosen animals.”

## 评审解释限制

匹配缓存是基于既有评审模型对“单条参考事实是否被单条候选句完整表达”的判断；不等于无误差的人工金标准。重合/保留仅为描述性流转证据，不构成严格因果中介证明。
