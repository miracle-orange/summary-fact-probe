#!/usr/bin/env python3
"""Reproducible offline analysis for the completed 300-meeting exp04 probe."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import re
import statistics
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

BASE = Path('/home/ma-user/work/dataset/summary-fact-probe')
RUN = BASE / 'runs/exp04-2gpu'
OUT = RUN / 'analysis/analysis-20261019-offline-01'
DATA = BASE / 'data/processed/meetings.jsonl'
REPO = BASE / 'meeting-fact-probe'
ARMS = ('direct_s', 'direct_l', 's_to_s', 's_to_l', 'l_to_s', 'l_to_l', 'gold_to_s', 'gold_to_l')
SOURCES = ('small', 'large')
METRICS = ('completeness', 'conciseness', 'faithfulness')
CROSS = ('s_to_s', 's_to_l', 'l_to_s', 'l_to_l')
A, B, C, D = CROSS
GEN_FACT = {'s_to_s': 'small', 's_to_l': 'small', 'l_to_s': 'large', 'l_to_l': 'large'}
FACT_FOR_ARM = {'s_to_s': 'small', 's_to_l': 'small', 'l_to_s': 'large', 'l_to_l': 'large', 'gold_to_s': 'gold', 'gold_to_l': 'gold'}
BOOTSTRAP = 2000
CONFIDENCE = 0.95
SEED = 42
TOL = 1e-10


def load_json(path: Path) -> Any:
    with path.open(encoding='utf-8') as f:
        return json.load(f)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('', encoding='utf-8-sig')
        return
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        fieldnames = list(dict.fromkeys(key for row in rows for key in row))
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest().upper()


def mean(xs: Iterable[float]) -> float:
    values = list(xs)
    return statistics.fmean(values) if values else float('nan')


def quantile_sorted(values: list[float], q: float) -> float:
    if not values:
        return float('nan')
    return values[min(len(values)-1, max(0, int(q * len(values))))]


def bootstrap_bounds(values: list[float]) -> tuple[float, float]:
    tail = (1.0 - CONFIDENCE) / 2.0
    return (values[max(0, int(tail * len(values)))],
            values[min(len(values)-1, int((1.0-tail) * len(values)) - 1)])


def bootstrap_indices(n: int, reps: int, seed: int) -> list[list[int]]:
    rng = random.Random(seed)
    return [[rng.randrange(n) for _ in range(n)] for _ in range(reps)]


def paired_interval(values: list[float], draws: list[list[int]]) -> tuple[float, float, float]:
    if not values:
        raise ValueError('bootstrap requires at least one paired observation')
    boot = sorted(mean(values[i] for i in ix) for ix in draws)
    tail = (1.0 - CONFIDENCE) / 2.0
    lower = boot[max(0, int(tail * len(boot)))]
    upper = boot[min(len(boot)-1, int((1.0-tail) * len(boot)) - 1)]
    return mean(values), lower, upper


def stats_distribution(values: list[float]) -> dict[str, float]:
    ordered = sorted(values)
    return {'mean': mean(values), 'median': statistics.median(values),
            'q1': quantile_sorted(ordered, .25), 'q3': quantile_sorted(ordered, .75),
            'min': min(values), 'max': max(values)}


def split_sentence_count(text: str) -> int:
    # Load the project's actual NLTK sentence tokenizer without importing evaluation's API clients.
    import nltk
    nltk.data.path.insert(0, str(BASE / 'cache/nltk'))
    sentences = [x.strip() for x in nltk.sent_tokenize(text) if x.strip()]
    if not sentences:
        raise ValueError('project NLTK sentence splitter returned no sentences')
    return len(sentences)


def word_count(text: str) -> int:
    # Unicode word tokens; internal apostrophes stay within one token.
    return len(re.findall(r"\b[\w]+(?:['’][\w]+)*\b", text, flags=re.UNICODE))


def source_line_evidence(conversation: str, fact: str) -> str:
    stop={'the','and','for','that','with','from','this','were','was','are','has','have','had','they',
          'their','there','about','into','will','would','could','should','been','being','which','when',
          'what','where','then','than','also','some','more','most','other','each','only','such','over',
          'under','while','through','because','after','before','between','both','very','much','many'}
    terms={x.lower() for x in re.findall(r"\b[\w]{3,}\b",fact,re.UNICODE) if x.lower() not in stop}
    if not conversation.strip():
        return ''
    all_words=[x.lower() for x in re.findall(r"\b[\w]{3,}\b",conversation,re.UNICODE)]
    frequencies=Counter(all_words)
    weights={term:math.log((len(all_words)+1)/(frequencies[term]+1))+1 for term in terms}
    windows=[]
    step=80
    width=280
    for start in range(0,len(conversation),step):
        excerpt=conversation[start:start+width].strip()
        if excerpt:
            words={x.lower() for x in re.findall(r"\b[\w]{3,}\b",excerpt,re.UNICODE)}
            overlap=words & terms
            score=sum(weights[x] for x in overlap)/math.sqrt(max(1,len(words)))
            windows.append((score,len(overlap),excerpt))
    best=max(windows,key=lambda item:(item[0],item[1]))
    if best[1] == 0:
        return '原文未找到明显词面对应的单句，需回查完整上下文'
    return best[2]


def record(path: Path, problems: list[dict[str, str]], label: str) -> dict[str, Any] | None:
    try:
        return load_json(path)
    except Exception as exc:
        problems.append({'item': label, 'path': str(path), 'reason': f'{type(exc).__name__}: {exc}'})
        return None


def check_ok_record(path: Path, sid: str, dataset: str, problems: list[dict[str, str]], label: str,
                    arm: str | None = None, source: str | None = None) -> dict[str, Any] | None:
    obj = record(path, problems, label)
    if obj is None:
        return None
    for key, expected in [('status', 'ok'), ('sample_id', sid), ('dataset', dataset)]:
        if obj.get(key) != expected:
            problems.append({'item': label, 'path': str(path), 'reason': f'{key}={obj.get(key)!r}, expected {expected!r}'})
    if arm is not None and obj.get('arm') != arm:
        problems.append({'item': label, 'path': str(path), 'reason': f'arm={obj.get("arm")!r}, expected {arm!r}'})
    if source is not None and obj.get('source') != source:
        problems.append({'item': label, 'path': str(path), 'reason': f'source={obj.get("source")!r}, expected {source!r}'})
    return obj


def check_match(path: Path, sid: str, expected: int, candidate_count: int,
                problems: list[dict[str, str]], label: str) -> dict[str, Any] | None:
    obj = record(path, problems, label)
    if obj is None:
        return None
    matches = obj.get('output', {}).get('matches') if isinstance(obj.get('output'), dict) else None
    if obj.get('status') != 'ok':
        problems.append({'item': label, 'path': str(path), 'reason': f'status={obj.get("status")!r}, expected "ok"'})
    if not isinstance(matches, list) or len(matches) != expected:
        problems.append({'item': label, 'path': str(path), 'reason': f'matches length={len(matches) if isinstance(matches,list) else type(matches).__name__}; expected {expected}'})
        return obj
    for i, item in enumerate(matches):
        if not isinstance(item, dict) or item.get('fact_idx') != i or 'align_unit_idx' not in item:
            problems.append({'item': label, 'path': str(path), 'reason': f'match at position {i} lacks continuous fact_idx/align_unit_idx'})
            continue
        idx = item['align_unit_idx']
        if idx is not None and (isinstance(idx, bool) or not isinstance(idx, int) or not 0 <= idx < candidate_count):
            problems.append({'item': label, 'path': str(path), 'reason': f'fact_idx {i}: align_unit_idx {idx!r} outside [0,{candidate_count})'})
    return obj


def fmt(v: Any, digits: int = 6) -> str:
    if v is None:
        return 'NA'
    if isinstance(v, float):
        return f'{v:.{digits}f}' if math.isfinite(v) else 'NA'
    return str(v)


def md_table(headers: list[str], rows: list[list[Any]]) -> str:
    out = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |']
    out += ['| ' + ' | '.join(str(x).replace('|', '\\|').replace('\n', ' ') for x in row) + ' |' for row in rows]
    return '\n'.join(out)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    problems: list[dict[str, str]] = []
    if not DATA.is_file():
        raise FileNotFoundError(f'missing dataset: {DATA}')
    rows_all = [json.loads(line) for line in DATA.read_text(encoding='utf-8').splitlines() if line.strip()]
    rows = [r for r in rows_all if 'all' in r.get('splits', [])]
    ids = [r.get('sample_id') for r in rows]
    if len(rows) != 300:
        problems.append({'item': 'selected dataset rows', 'path': str(DATA), 'reason': f'found {len(rows)}, expected 300 with split all'})
    dup_ids = sorted(s for s, n in Counter(ids).items() if n != 1)
    if dup_ids:
        problems.append({'item': 'sample_id uniqueness', 'path': str(DATA), 'reason': f'duplicate IDs: {dup_ids}'})
    datasets = Counter(r.get('dataset') for r in rows)
    if len(datasets) != 5:
        problems.append({'item': 'source count', 'path': str(DATA), 'reason': f'found {len(datasets)} sources: {dict(datasets)}'})

    status_path = RUN / 'metrics/evaluation-status.json'
    status = record(status_path, problems, 'evaluation status')
    if status is not None and (status.get('requested') != 3000 or status.get('failures') != []):
        problems.append({'item': 'evaluation status', 'path': str(status_path), 'reason': f"expected requested=3000, failures=[]; got requested={status.get('requested')!r}, failures={status.get('failures')!r}"})

    summaries: dict[str, dict[str, dict[str, Any]]] = {a: {} for a in ARMS}
    facts: dict[str, dict[str, dict[str, Any]]] = {s: {} for s in SOURCES}
    gensumm: dict[str, dict[str, Any]] = {a: {} for a in ARMS}
    genfacts: dict[str, dict[str, Any]] = {s: {} for s in SOURCES}
    summary_matches: dict[str, dict[str, set[int]]] = {a: {} for a in ARMS}
    fact_matches: dict[str, dict[str, set[int]]] = {s: {} for s in SOURCES}
    sample_by_id = {r['sample_id']: r for r in rows if r.get('sample_id')}

    # Hard gate: all 3,000 metric records and every corresponding generation/match cache must parse and align.
    for row in rows:
        sid, dataset = row['sample_id'], row['dataset']
        gold_n = len(row.get('key_facts', []))
        if not gold_n:
            problems.append({'item': f'{sid}/gold facts', 'path': str(DATA), 'reason': 'empty or absent key_facts'})
        for arm in ARMS:
            mp = RUN / 'metrics/summaries' / arm / f'{sid}.json'
            mr = check_ok_record(mp, sid, dataset, problems, f'metrics summary {arm}/{sid}', arm=arm)
            gp = RUN / 'generation/summaries' / arm / f'{sid}.json'
            gr = record(gp, problems, f'generation summary {arm}/{sid}')
            if gr is not None:
                if gr.get('status') != 'ok' or not isinstance(gr.get('output', {}).get('summary'), str) or not gr['output']['summary'].strip():
                    problems.append({'item': f'generation summary {arm}/{sid}', 'path': str(gp), 'reason': 'status/output.summary missing or invalid'})
                else:
                    text = gr['output']['summary']
                    try:
                        n_sent = split_sentence_count(text)
                        if mr is not None and mr.get('sentence_count') != n_sent:
                            problems.append({'item': f'sentence_count {arm}/{sid}', 'path': str(mp), 'reason': f"metric={mr.get('sentence_count')!r}, evaluate.py NLTK count={n_sent}"})
                        gensumm[arm][sid] = gr
                    except Exception as exc:
                        problems.append({'item': f'sentence split {arm}/{sid}', 'path': str(gp), 'reason': f'{type(exc).__name__}: {exc}'})
            ev = check_match(RUN / 'evaluation/summaries' / arm / 'match' / f'{sid}.json', sid, gold_n,
                             int(mr.get('sentence_count', 0)) if mr else 0, problems, f'summary match {arm}/{sid}')
            if ev is not None and isinstance(ev.get('output', {}).get('matches'), list):
                summary_matches[arm][sid] = {x['fact_idx'] for x in ev['output']['matches'] if isinstance(x, dict) and x.get('align_unit_idx') is not None and isinstance(x.get('fact_idx'), int)}
            if mr is not None:
                for m in METRICS:
                    if not isinstance(mr.get(m), (float, int)) or not math.isfinite(float(mr[m])):
                        problems.append({'item': f'metrics summary {arm}/{sid}', 'path': str(mp), 'reason': f'{m} missing/non-finite'})
                summaries[arm][sid] = mr
        for src in SOURCES:
            mp = RUN / 'metrics/facts' / src / f'{sid}.json'
            mr = check_ok_record(mp, sid, dataset, problems, f'metrics facts {src}/{sid}', source=src)
            gp = RUN / 'generation/facts' / src / f'{sid}.json'
            gr = record(gp, problems, f'generation facts {src}/{sid}')
            fact_list = None
            if gr is not None:
                fact_list = gr.get('output', {}).get('key_facts')
                if gr.get('status') != 'ok' or not isinstance(fact_list, list) or not fact_list or not all(isinstance(x, str) and x.strip() for x in fact_list):
                    problems.append({'item': f'generation facts {src}/{sid}', 'path': str(gp), 'reason': 'status/output.key_facts missing or invalid'})
                    fact_list = None
                else:
                    genfacts[src][sid] = gr
            ev = check_match(RUN / 'evaluation/facts' / src / 'match' / f'{sid}.json', sid, gold_n,
                             len(fact_list) if fact_list is not None else 0, problems, f'fact match {src}/{sid}')
            if ev is not None and isinstance(ev.get('output', {}).get('matches'), list):
                fact_matches[src][sid] = {x['fact_idx'] for x in ev['output']['matches'] if isinstance(x, dict) and x.get('align_unit_idx') is not None and isinstance(x.get('fact_idx'), int)}
            if mr is not None:
                for m in ('coverage', 'support', 'fact_count', 'character_count'):
                    if not isinstance(mr.get(m), (float, int)) or not math.isfinite(float(mr[m])):
                        problems.append({'item': f'metrics facts {src}/{sid}', 'path': str(mp), 'reason': f'{m} missing/non-finite'})
                if fact_list is not None and (mr.get('fact_count') != len(fact_list) or mr.get('character_count') != sum(map(len, fact_list))):
                    problems.append({'item': f'metrics facts {src}/{sid}', 'path': str(mp), 'reason': f"fact_count/character_count disagree with generation list ({len(fact_list)}, {sum(map(len, fact_list))})"})
                facts[src][sid] = mr

    # Validate report tables and their exact arithmetic before doing substantive analysis.
    report_files = [RUN/'report/summary-metrics.csv', RUN/'report/contrasts.csv', RUN/'report/fact-extraction.csv']
    for p in report_files:
        if not p.is_file():
            problems.append({'item': 'report input', 'path': str(p), 'reason': 'missing required report CSV'})
    if len(summaries) and all(len(summaries[a]) == len(rows) for a in ARMS) and all(p.is_file() for p in report_files):
        report_summary = read_csv(report_files[0])
        for arm in ARMS:
            r = next((x for x in report_summary if x['arm'] == arm and x['dataset'] == 'ALL'), None)
            for metric in METRICS:
                actual = mean(float(summaries[arm][sid][metric]) for sid in sample_by_id)
                if r is None or abs(float(r[metric]) - actual) > TOL:
                    problems.append({'item': f'report mean {arm}/{metric}', 'path': str(report_files[0]), 'reason': f'CSV={r.get(metric) if r else None}, recomputed={actual:.17g}, tolerance={TOL}'})
        contrast_csv = read_csv(report_files[1])
        old_contrasts = [('direct_l','direct_s'),('s_to_s','direct_s'),('l_to_s','s_to_s'),('l_to_s','direct_s'),('gold_to_l','gold_to_s'),('s_to_l','l_to_l')]
        for mi, metric in enumerate(METRICS):
            for left, right in old_contrasts:
                diff = [float(summaries[left][sid][metric])-float(summaries[right][sid][metric]) for sid in sample_by_id]
                obs, lo, hi = paired_interval(diff, bootstrap_indices(len(diff), BOOTSTRAP, SEED+mi))
                match = next((x for x in contrast_csv if x['contrast']==f'{left} - {right}' and x['metric']==metric), None)
                expected = {'difference':obs,'ci_lower':lo,'ci_upper':hi}
                for k,v in expected.items():
                    if match is None or abs(float(match[k])-v)>TOL:
                        problems.append({'item': f'report contrast {left}-{right}/{metric}/{k}', 'path': str(report_files[1]), 'reason': f'CSV={match.get(k) if match else None}, recomputed={v:.17g}, tolerance={TOL}'})
        fact_csv = read_csv(report_files[2])
        for src in SOURCES:
            r = next((x for x in fact_csv if x['source']==src), None)
            for k in ('coverage','support','fact_count','character_count'):
                actual=mean(float(facts[src][sid][k]) for sid in sample_by_id)
                if r is None or abs(float(r[k])-actual)>TOL:
                    problems.append({'item': f'report fact mean {src}/{k}', 'path': str(report_files[2]), 'reason': f'CSV={r.get(k) if r else None}, recomputed={actual:.17g}, tolerance={TOL}'})

    if problems:
        write_csv(OUT/'missing-inputs.csv', problems)
        write_json(OUT/'manifest.json', {'analysis_time_utc':datetime.now(timezone.utc).isoformat(), 'status':'stopped_integrity_gate',
            'inputs':{'data':str(DATA),'run':str(RUN)},'selected_samples':len(rows),'source_counts':dict(datasets),
            'analysis_script_sha256':sha256(Path(__file__)), 'bootstrap':{'replicates':BOOTSTRAP,'confidence':CONFIDENCE,'seed':SEED},
            'problem_count':len(problems),'missing_or_inconsistent_items':problems})
        print(f'Integrity gate failed: {len(problems)} issue(s). See {OUT / "missing-inputs.csv"}', file=sys.stderr)
        return 2
    stale_failure_list = OUT / 'missing-inputs.csv'
    if stale_failure_list.exists():
        stale_failure_list.unlink()

    # Build complete long-form per-arm metrics and lengths.
    per_arms=[]
    lengths={arm:{} for arm in ARMS}
    for row in rows:
        sid,dataset=row['sample_id'],row['dataset']
        for arm in ARMS:
            mr=summaries[arm][sid]; gr=gensumm[arm][sid]; text=gr['output']['summary']; usage=gr.get('metadata',{}).get('usage',{}) or {}
            nchar=len(text); nwords=word_count(text); n_sent=int(mr['sentence_count']); natomic=int(mr['atomic_fact_count'])
            lengths[arm][sid]={'characters':nchar,'words':nwords,'sentence_count':n_sent,'atomic_fact_count':natomic,
                               'completion_tokens':usage.get('completion_tokens')}
            per_arms.append({'sample_id':sid,'dataset':dataset,'arm':arm,**{m:float(mr[m]) for m in METRICS},
                'sentence_count':n_sent,'atomic_fact_count':natomic,'character_count':nchar,'word_count':nwords,
                'completion_tokens':usage.get('completion_tokens')})
    write_csv(OUT/'per_sample_arms.csv',per_arms)

    # Extraction distributions, exact duplicates and paired deltas.
    per_facts=[]; duplicate_cases=[]
    for row in rows:
        sid,dataset=row['sample_id'],row['dataset']
        for src in SOURCES:
            mr=facts[src][sid]; fl=genfacts[src][sid]['output']['key_facts']; counts=Counter(fl)
            dup=sum(n-1 for n in counts.values()); dup_rate=dup/len(fl)
            if dup:
                duplicate_cases.append({'sample_id':sid,'dataset':dataset,'source':src,'fact_count':len(fl),'duplicate_count':dup,'duplicate_rate':dup_rate,'duplicates':[x for x,n in counts.items() if n>1]})
            per_facts.append({'sample_id':sid,'dataset':dataset,'source':src,'coverage':float(mr['coverage']),'support':float(mr['support']),
                'fact_count':int(mr['fact_count']),'character_count':int(mr['character_count']),'exact_duplicate_count':dup,'duplicate_rate':dup_rate,
                'matched_gold_ids':','.join(map(str,sorted(fact_matches[src][sid])))})
    write_csv(OUT/'per_sample_facts.csv',per_facts)

    # Crossed factorial effects, with meeting-level vectors and strict algebra checks.
    cross={m:{} for m in METRICS}
    cross_rows=[]
    for row in rows:
        sid=row['sample_id']; out={'sample_id':sid,'dataset':row['dataset']}
        for metric in METRICS:
            vals={arm:float(summaries[arm][sid][metric]) for arm in CROSS}
            es=vals[C]-vals[A]; el=vals[D]-vals[B]; gs=vals[B]-vals[A]; gl=vals[D]-vals[C]
            de=(es+el)/2; dg=(gs+gl)/2; cb=vals[C]-vals[B]
            if abs((de-dg)-cb)>1e-12:
                problems.append({'item':f'algebra {sid}/{metric}','path':str(OUT/'per_sample_cross.csv'),'reason':f'DeltaE-DeltaG={de-dg}, C-B={cb}'})
            cross[metric][sid]={'A':vals[A],'B':vals[B],'C':vals[C],'D':vals[D],'E_s':es,'E_l':el,'G_s':gs,'G_l':gl,'Delta_E':de,'Delta_G':dg,'C_minus_B':cb}
            for name,value in cross[metric][sid].items(): out[f'{metric}_{name}']=value
        cross_rows.append(out)
    if problems:
        write_csv(OUT/'missing-inputs.csv',problems)
        return 2
    write_csv(OUT/'per_sample_cross.csv',cross_rows)

    # Bootstrap all core contrasts with a single set of paired meeting resamples per metric.
    effects=[]; effect_values={}
    core_names=('E_s','E_l','G_s','G_l','Delta_E','Delta_G','C_minus_B','Delta_E_minus_Delta_G')
    for mi,metric in enumerate(METRICS):
        draws=bootstrap_indices(len(rows),BOOTSTRAP,SEED+mi)
        ordered_ids=[r['sample_id'] for r in rows]
        for name in core_names:
            vals=[]
            for sid in ordered_ids:
                d=cross[metric][sid]
                vals.append(d['Delta_E']-d['Delta_G'] if name=='Delta_E_minus_Delta_G' else d[name])
            obs,lo,hi=paired_interval(vals,draws); dist=stats_distribution(vals)
            effects.append({'metric':metric,'effect':name,'n':len(vals),'mean':obs,'ci_lower':lo,'ci_upper':hi,
                'median':dist['median'],'q1':dist['q1'],'q3':dist['q3'],'positive_n':sum(x>0 for x in vals),'zero_n':sum(x==0 for x in vals),'negative_n':sum(x<0 for x in vals),
                'unit':'proportion (0-1); multiply by 100 for percentage points','bootstrap_replicates':BOOTSTRAP,'seed':SEED+mi})
            effect_values[(metric,name)]=vals
        # Basic A/B/C/D means to provide context and source reporting.
        for arm in CROSS:
            effects.append({'metric':metric,'effect':f'mean_{arm}','n':len(rows),'mean':mean(float(summaries[arm][sid][metric]) for sid in ordered_ids),
                'ci_lower':'','ci_upper':'','median':'','q1':'','q3':'','positive_n':'','zero_n':'','negative_n':'','unit':'proportion (0-1)','bootstrap_replicates':BOOTSTRAP,'seed':SEED+mi})
    write_csv(OUT/'paired_effects.csv',effects)

    # Per-source factorial results. Intervals are explicitly exploratory.
    by_source=[]
    for dataset in sorted(datasets):
        selected=[r['sample_id'] for r in rows if r['dataset']==dataset]
        for metric in METRICS:
            draws=bootstrap_indices(len(selected),BOOTSTRAP,SEED+METRICS.index(metric))
            data={name:[] for name in (*CROSS,'Delta_E','Delta_G','C_minus_B')}
            for sid in selected:
                d=cross[metric][sid]
                for name, key in zip(CROSS, ('A', 'B', 'C', 'D')): data[name].append(d[key])
                data['Delta_E'].append(d['Delta_E']); data['Delta_G'].append(d['Delta_G']); data['C_minus_B'].append(d['C_minus_B'])
            rowout={'dataset':dataset,'metric':metric,'n':len(selected),'interval_note':'exploratory, paired percentile bootstrap'}
            for arm in CROSS: rowout[f'mean_{arm}']=mean(data[arm])
            for name in ('Delta_E','Delta_G','C_minus_B'):
                obs,lo,hi=paired_interval(data[name],draws)
                rowout.update({f'{name}_mean':obs,f'{name}_ci_lower':lo,f'{name}_ci_upper':hi})
            by_source.append(rowout)
    write_csv(OUT/'by_source.csv',by_source)

    # Equal-source-weighted descriptive estimates, kept separate from the 300-meeting primary mean.
    equal_source={}
    for metric in METRICS:
        equal_source[metric]={}
        for name in ('Delta_E','Delta_G','C_minus_B'):
            equal_source[metric][name]=mean(row[f'{name}_mean'] for row in by_source if row['metric']==metric)

    # Generation model gap by fact condition; ratio of aggregate means, not mean of ratios.
    conditions={'direct':('direct_s','direct_l'),'small_facts':('s_to_s','s_to_l'),'large_facts':('l_to_s','l_to_l'),'gold':('gold_to_s','gold_to_l')}
    gap_rows=[]; gap_draws=bootstrap_indices(len(rows),BOOTSTRAP,SEED)
    boot_gap={}
    for cond,(small_arm,large_arm) in conditions.items():
        sm=mean(float(summaries[small_arm][r['sample_id']]['completeness']) for r in rows)
        lg=mean(float(summaries[large_arm][r['sample_id']]['completeness']) for r in rows)
        gap=lg-sm; rel=gap/sm if sm!=0 else None; symmetric=gap/((lg+sm)/2) if lg+sm else None
        bg=[]; br=[]; bs=[]; invalid=0
        for ix in gap_draws:
            sample=[rows[i]['sample_id'] for i in ix]
            msmall=mean(float(summaries[small_arm][sid]['completeness']) for sid in sample)
            mlarge=mean(float(summaries[large_arm][sid]['completeness']) for sid in sample)
            bg.append(mlarge-msmall)
            if msmall == 0:
                invalid+=1
            else:
                br.append((mlarge-msmall)/msmall)
            bs.append((mlarge-msmall)/((mlarge+msmall)/2) if (mlarge+msmall)!=0 else float('nan'))
        bg.sort(); br.sort(); bs_valid=sorted(x for x in bs if math.isfinite(x))
        bg_lo,bg_hi=bootstrap_bounds(bg)
        br_lo,br_hi=bootstrap_bounds(br) if br else (None,None)
        bs_lo,bs_hi=bootstrap_bounds(bs_valid) if bs_valid else (None,None)
        boot_gap[cond]={'absolute':bg,'relative':br}
        gap_rows.append({'condition':cond,'small_generator_arm':small_arm,'large_generator_arm':large_arm,'small_mean':sm,'large_mean':lg,
            'absolute_gap_large_minus_small':gap,'absolute_gap_ci_lower':bg_lo,'absolute_gap_ci_upper':bg_hi,
            'relative_gap_over_small':rel,'relative_gap_ci_lower':br_lo,'relative_gap_ci_upper':br_hi,
            'symmetric_relative_gap_supplement':symmetric,'symmetric_gap_ci_lower':bs_lo,'symmetric_gap_ci_upper':bs_hi,
            'invalid_small_denominator_resamples':invalid,'relative_ci_rule':'exclude invalid replicate denominator; report count; point estimate uses ratio of overall means','unit':'absolute: proportion, x100=percentage points; relative: ratio'})
    gap_by={x['condition']:x for x in gap_rows}
    for target in ('small_facts','large_facts','gold'):
        g=gap_by['direct']['absolute_gap_large_minus_small']-gap_by[target]['absolute_gap_large_minus_small']
        grel=gap_by['direct']['relative_gap_over_small']-gap_by[target]['relative_gap_over_small']
        babs=[a-b for a,b in zip(boot_gap['direct']['absolute'],boot_gap[target]['absolute'])]
        brel=[a-b for a,b in zip(boot_gap['direct']['relative'],boot_gap[target]['relative'])]
        gap_by[target]['absolute_gap_shrink_vs_direct']=g
        gap_by[target]['absolute_shrink_ci_lower'],gap_by[target]['absolute_shrink_ci_upper']=bootstrap_bounds(sorted(babs))
        gap_by[target]['relative_gap_shrink_vs_direct']=grel
        gap_by[target]['relative_shrink_ci_lower'],gap_by[target]['relative_shrink_ci_upper']=bootstrap_bounds(sorted(brel)) if brel else (None,None)
    write_csv(OUT/'gap_analysis.csv',gap_rows)

    # Paired fact extraction summaries, with distributions, deltas and exact-duplicate diagnostics.
    fact_summary=[]
    paired_fact=[]
    metric_fact=('coverage','support','fact_count','character_count')
    for metric in metric_fact:
        vals={src:[float(facts[src][r['sample_id']][metric]) for r in rows] for src in SOURCES}
        deltas=[b-a for a,b in zip(vals['small'],vals['large'])]
        obs,lo,hi=paired_interval(deltas,bootstrap_indices(len(rows),BOOTSTRAP,SEED+metric_fact.index(metric)))
        dist=stats_distribution(deltas)
        paired_fact.append({'metric':metric,'small_mean':mean(vals['small']),'large_mean':mean(vals['large']),'large_minus_small':obs,'ci_lower':lo,'ci_upper':hi,
            'median_delta':dist['median'],'q1_delta':dist['q1'],'q3_delta':dist['q3'],'positive_n':sum(x>0 for x in deltas),'zero_n':sum(x==0 for x in deltas),'negative_n':sum(x<0 for x in deltas),
            'small_distribution':json.dumps(stats_distribution(vals['small'])),'large_distribution':json.dumps(stats_distribution(vals['large']))})
        for src in SOURCES:
            dv=[float(facts[src][r['sample_id']][metric]) for r in rows]
            fact_summary.append({'source':src,'metric':metric,**stats_distribution(dv)})
    exact_duplicate_total={src:sum(int(x['exact_duplicate_count']) for x in per_facts if x['source']==src) for src in SOURCES}
    fact_totals={src:sum(int(x['fact_count']) for x in per_facts if x['source']==src) for src in SOURCES}
    for src in SOURCES:
        fact_summary.append({'source':src,'metric':'exact_duplicate_count_total','mean':mean(int(x['exact_duplicate_count']) for x in per_facts if x['source']==src),
            'total_duplicate_occurrences':exact_duplicate_total[src],'duplicate_occurrences_per_fact':exact_duplicate_total[src]/fact_totals[src] if fact_totals[src] else None,
            'samples_with_duplicates':sum(int(x['exact_duplicate_count'])>0 for x in per_facts if x['source']==src)})
    write_csv(OUT/'fact_quality_summary.csv',fact_summary)
    write_csv(OUT/'fact_quality_paired.csv',paired_fact)
    write_csv(OUT/'duplicate_cases.csv',duplicate_cases)
    fact_source_rows=[]
    for dataset in sorted(datasets):
        ds_ids=[r['sample_id'] for r in rows if r['dataset']==dataset]
        for src in SOURCES:
            for metric in metric_fact:
                vals=[float(facts[src][sid][metric]) for sid in ds_ids]
                fact_source_rows.append({'dataset':dataset,'source':src,'metric':metric,'n':len(vals),**stats_distribution(vals)})
            dup_vals=[next(x for x in per_facts if x['sample_id']==sid and x['source']==src)['exact_duplicate_count'] for sid in ds_ids]
            fact_source_rows.append({'dataset':dataset,'source':src,'metric':'exact_duplicate_count','n':len(dup_vals),**stats_distribution(list(map(float,dup_vals))),
                'samples_with_duplicates':sum(x>0 for x in dup_vals)})
    write_csv(OUT/'fact_quality_by_source.csv',fact_source_rows)
    # Descriptive association of coverage change with output volume change.
    def corr(x: list[float], y: list[float]) -> float | None:
        mx,my=mean(x),mean(y); denom=math.sqrt(sum((a-mx)**2 for a in x)*sum((b-my)**2 for b in y))
        return sum((a-mx)*(b-my) for a,b in zip(x,y))/denom if denom else None
    coverage_delta=[float(facts['large'][r['sample_id']]['coverage'])-float(facts['small'][r['sample_id']]['coverage']) for r in rows]
    count_delta=[float(facts['large'][r['sample_id']]['fact_count'])-float(facts['small'][r['sample_id']]['fact_count']) for r in rows]
    char_delta=[float(facts['large'][r['sample_id']]['character_count'])-float(facts['small'][r['sample_id']]['character_count']) for r in rows]
    corr_summary={'coverage_change_vs_fact_count_change_pearson':corr(coverage_delta,count_delta),'coverage_change_vs_character_count_change_pearson':corr(coverage_delta,char_delta),
        'both_coverage_and_count_increased':sum(a>0 and b>0 for a,b in zip(coverage_delta,count_delta)),
        'both_coverage_and_characters_increased':sum(a>0 and b>0 for a,b in zip(coverage_delta,char_delta)),
        'coverage_increased':sum(x>0 for x in coverage_delta),'count_increased':sum(x>0 for x in count_delta),'characters_increased':sum(x>0 for x in char_delta)}
    write_json(OUT/'fact_volume_association.json',corr_summary)
    few_fact_ids=sorted(sid for sid in sample_by_id if len(genfacts['small'][sid]['output']['key_facts'])<=5)
    repeat_ids=sorted(sid for sid in sample_by_id if next(x for x in per_facts if x['sample_id']==sid and x['source']=='small')['exact_duplicate_count']>=3)
    write_json(OUT/'diagnostic_groups.json',{'predeclared_rules':{'few_small_facts':'small extractor fact_count <= 5','many_exact_repeats':'small extractor exact duplicate occurrences >= 3'},
        'few_small_fact_sample_ids':few_fact_ids,'few_small_fact_n':len(few_fact_ids),'many_repeat_sample_ids':repeat_ids,'many_repeat_n':len(repeat_ids)})
    diagnostic_rows=[]
    diagnostic_sets={'small_fact_count_le_5':set(few_fact_ids),'small_exact_duplicates_ge_3':set(repeat_ids)}
    for group,group_ids in diagnostic_sets.items():
        for label,chosen in (('diagnostic_group',group_ids),('all_other_meetings',set(sample_by_id)-group_ids)):
            for metric in METRICS:
                vals=[cross[metric][sid] for sid in sorted(chosen)]
                diagnostic_rows.append({'group':group,'subset':label,'metric':metric,'n':len(vals),
                    'Delta_E_mean':mean(x['Delta_E'] for x in vals) if vals else None,
                    'Delta_G_mean':mean(x['Delta_G'] for x in vals) if vals else None,
                    'C_minus_B_mean':mean(x['C_minus_B'] for x in vals) if vals else None,
                    'C_minus_B_positive_n':sum(x['C_minus_B']>0 for x in vals),
                    'C_minus_B_zero_n':sum(x['C_minus_B']==0 for x in vals),
                    'C_minus_B_negative_n':sum(x['C_minus_B']<0 for x in vals)})
    write_csv(OUT/'diagnostic_impact.csv',diagnostic_rows)

    # Reference-fact flow using cached judge matches (descriptive only).
    flow=[]
    arm_to_fact={'s_to_s':'small','s_to_l':'small','l_to_s':'large','l_to_l':'large','gold_to_s':'gold','gold_to_l':'gold'}
    for row in rows:
        sid=row['sample_id']; S=fact_matches['small'][sid]; L=fact_matches['large'][sid]
        out={'sample_id':sid,'dataset':row['dataset'],'S_ids':','.join(map(str,sorted(S))),'L_ids':','.join(map(str,sorted(L))),
             'S_n':len(S),'L_n':len(L),'L_not_S_n':len(L-S),'S_not_L_n':len(S-L),'intersection_n':len(S&L),'L_not_S_ids':','.join(map(str,sorted(L-S)))}
        for arm in (*CROSS,'gold_to_s','gold_to_l'):
            T=summary_matches[arm][sid]
            out[f'T_{arm}_ids']=','.join(map(str,sorted(T))); out[f'T_{arm}_n']=len(T)
            source=arm_to_fact[arm]
            source_set=S if source=='small' else L if source=='large' else set(range(len(row['key_facts'])))
            out[f'{arm}_fact_list_uncovered_summary_added_n']=len(T-source_set)
            out[f'{arm}_fact_list_covered_summary_dropped_n']=len(source_set-T)
        extra=L-S
        for arm in CROSS:
            T=summary_matches[arm][sid]
            out[f'L_extra_retained_{arm}_n']=len(extra&T)
            out[f'L_extra_retained_{arm}_denom']=len(extra)
            out[f'L_extra_retained_{arm}_rate']=len(extra&T)/len(extra) if extra else None
        flow.append(out)
    write_csv(OUT/'fact_flow.csv',flow)
    flow_summary=[]
    flow_dimensions=['L_extra_retained_l_to_s','L_extra_retained_l_to_l','L_extra_retained_s_to_s','L_extra_retained_s_to_l']
    for dim in flow_dimensions:
        nums=[int(x[f'{dim}_n']) for x in flow]; dens=[int(x[f'{dim}_denom']) for x in flow]
        rates=[x[f'{dim}_rate'] for x in flow if x[f'{dim}_rate'] is not None]
        flow_summary.append({'measure':dim,'meetings_applicable':len(rates),'meetings_not_applicable_denominator_zero':len(flow)-len(rates),
            'meeting_average_rate':mean(rates) if rates else None,'pooled_numerator':sum(nums),'pooled_denominator':sum(dens),
            'pooled_rate':sum(nums)/sum(dens) if sum(dens) else None})
    for arm in (*CROSS,'gold_to_s','gold_to_l'):
        for kind in ('fact_list_uncovered_summary_added','fact_list_covered_summary_dropped'):
            vals=[int(x[f'{arm}_{kind}_n']) for x in flow]
            flow_summary.append({'measure':f'{arm}_{kind}','meeting_average_count':mean(vals),'pooled_count':sum(vals)})
    write_csv(OUT/'fact_flow_summary.csv',flow_summary)
    flow_by_source=[]
    for ds in sorted(datasets):
        subset=[x for x in flow if x['dataset']==ds]
        for dim in flow_dimensions:
            ns=[int(x[f'{dim}_n']) for x in subset]; dsx=[int(x[f'{dim}_denom']) for x in subset]
            applicable=[x[f'{dim}_rate'] for x in subset if x[f'{dim}_rate'] is not None]
            flow_by_source.append({'dataset':ds,'measure':dim,'n_meetings':len(subset),'meeting_average_rate':mean(applicable) if applicable else None,
                'pooled_numerator':sum(ns),'pooled_denominator':sum(dsx),'pooled_rate':sum(ns)/sum(dsx) if sum(dsx) else None})
    write_csv(OUT/'fact_flow_by_source.csv',flow_by_source)
    flow_by_gain=[]
    for dataset in sorted(datasets):
        for sign in ('positive','zero','negative'):
            subset=[x for x in flow if x['dataset']==dataset and
                    (cross['completeness'][x['sample_id']]['C_minus_B'] > 0 if sign=='positive' else
                     cross['completeness'][x['sample_id']]['C_minus_B'] == 0 if sign=='zero' else
                     cross['completeness'][x['sample_id']]['C_minus_B'] < 0)]
            for dim in flow_dimensions:
                numerators=[int(x[f'{dim}_n']) for x in subset]
                denominators=[int(x[f'{dim}_denom']) for x in subset]
                rates=[x[f'{dim}_rate'] for x in subset if x[f'{dim}_rate'] is not None]
                flow_by_gain.append({'dataset':dataset,'C_minus_B_completeness_sign':sign,'n_meetings':len(subset),
                    'measure':dim,'applicable_meetings':len(rates),'meeting_average_rate':mean(rates) if rates else None,
                    'pooled_numerator':sum(numerators),'pooled_denominator':sum(denominators),
                    'pooled_rate':sum(numerators)/sum(denominators) if sum(denominators) else None})
    write_csv(OUT/'fact_flow_by_source_gain.csv',flow_by_gain)

    # Length differences and paired effect/quality diagnostics.
    length_effects=[]
    length_comparisons=[('E_s','l_to_s','s_to_s'),('E_l','l_to_l','s_to_l'),('C_minus_B','l_to_s','s_to_l'),('gold_vs_direct_small','gold_to_s','direct_s'),('gold_vs_direct_large','gold_to_l','direct_l')]
    for metric in ('characters','words','sentence_count','atomic_fact_count','completion_tokens'):
        available=0
        for name,left,right in length_comparisons:
            diffs=[]
            for row in rows:
                sid=row['sample_id']; lv=lengths[left][sid].get(metric); rv=lengths[right][sid].get(metric)
                if isinstance(lv,(int,float)) and isinstance(rv,(int,float)): diffs.append(float(lv)-float(rv))
            if not diffs: continue
            draws=bootstrap_indices(len(diffs),BOOTSTRAP,SEED+length_comparisons.index((name,left,right)))
            obs,lo,hi=paired_interval(diffs,draws); d=stats_distribution(diffs)
            length_effects.append({'measurement':metric,'comparison':name,'left_minus_right':obs,'ci_lower':lo,'ci_upper':hi,
                'median':d['median'],'q1':d['q1'],'q3':d['q3'],'positive_n':sum(x>0 for x in diffs),'zero_n':sum(x==0 for x in diffs),'negative_n':sum(x<0 for x in diffs),'n':len(diffs)})
    write_csv(OUT/'length_effects.csv',length_effects)
    length_dist=[]
    for arm in ARMS:
        for measure in ('characters','words','sentence_count','atomic_fact_count','completion_tokens'):
            vals=[lengths[arm][r['sample_id']][measure] for r in rows if isinstance(lengths[arm][r['sample_id']][measure],(int,float))]
            missing=len(rows)-len(vals)
            length_dist.append({'arm':arm,'measure':measure,'n':len(vals),'missing_n':missing,**(stats_distribution(list(map(float,vals))) if vals else {})})
    write_csv(OUT/'length_distributions.csv',length_dist)

    # Exception IDs based only on registered override and successful retry records.
    override_path=RUN/'manual-summary-overrides.json'; recovery_dir=RUN/'evaluation-format-recovery'
    override=load_json(override_path) if override_path.exists() else {'sample_ids':[]}
    override_ids=set(override.get('sample_ids',[]))
    recovery_ids=set()
    recovery_success=[]
    for success_path in sorted(recovery_dir.glob('**/format-retry.success.json')):
        attempt=success_path.parent
        requests_path=attempt/'requests.json'
        req=load_json(requests_path) if requests_path.exists() else {}
        cache=req.get('cache_path','') if isinstance(req,dict) else ''
        sid_match=re.search(r'(meeting-\d+)\.json',str(cache))
        if sid_match:
            recovery_ids.add(sid_match.group(1)); recovery_success.append({'sample_id':sid_match.group(1),'success_record':str(success_path),'cache_path':cache})
        else:
            # Some registries store per-request records in a list.
            entries=req if isinstance(req,list) else req.get('requests',[]) if isinstance(req,dict) else []
            for entry in entries:
                m=re.search(r'(meeting-\d+)\.json',str(entry.get('cache_path','')))
                if m:
                    recovery_ids.add(m.group(1)); recovery_success.append({'sample_id':m.group(1),'success_record':str(success_path),'cache_path':entry.get('cache_path')})
    write_json(OUT/'protocol_exceptions.json',{'manual_override_ids':sorted(override_ids),'manual_override_records':override,
        'format_retry_sample_ids':sorted(recovery_ids),'format_retry_success_records':recovery_success,
        'ids_not_in_selected_300':sorted((override_ids|recovery_ids)-set(sample_by_id))})
    named_ids=['meeting-0078','meeting-0290','meeting-0571','meeting-0761','meeting-1696','meeting-1719',
        'meeting-1776','meeting-0550','meeting-1164','meeting-1707']
    named_rows=[]
    for sid in named_ids:
        if sid not in sample_by_id:
            named_rows.append({'sample_id':sid,'found_in_selected_300':False})
            continue
        row=sample_by_id[sid]
        small_fact=next(x for x in per_facts if x['sample_id']==sid and x['source']=='small')
        large_fact=next(x for x in per_facts if x['sample_id']==sid and x['source']=='large')
        named_rows.append({'sample_id':sid,'found_in_selected_300':True,'dataset':row['dataset'],
            'small_coverage':small_fact['coverage'],'small_support':small_fact['support'],'small_fact_count':small_fact['fact_count'],
            'small_duplicate_count':small_fact['exact_duplicate_count'],'large_coverage':large_fact['coverage'],
            'large_support':large_fact['support'],'large_fact_count':large_fact['fact_count'],
            'A_completeness':summaries[A][sid]['completeness'],'B_completeness':summaries[B][sid]['completeness'],
            'C_completeness':summaries[C][sid]['completeness'],'D_completeness':summaries[D][sid]['completeness'],
            'C_minus_B':cross['completeness'][sid]['C_minus_B'],'manual_override':sid in override_ids,
            'format_retry':sid in recovery_ids})
    write_csv(OUT/'named_samples.csv',named_rows)
    sensitivity=[]
    scenarios=[('all_300',set()),('exclude_manual_override',override_ids),('exclude_format_retry',recovery_ids),('exclude_union',override_ids|recovery_ids)]
    for scenario,excluded in scenarios:
        subset=[r['sample_id'] for r in rows if r['sample_id'] not in excluded]
        idx=[next(i for i,r in enumerate(rows) if r['sample_id']==sid) for sid in subset]
        for metric in METRICS:
            draws=bootstrap_indices(len(subset),BOOTSTRAP,SEED+METRICS.index(metric))
            cols={name:[] for name in ('Delta_E','Delta_G','C_minus_B')}
            for sid in subset:
                q=cross[metric][sid]
                cols['Delta_E'].append(q['Delta_E']); cols['Delta_G'].append(q['Delta_G']); cols['C_minus_B'].append(q['C_minus_B'])
            vals_ci={}
            for name,v in cols.items():
                obs,lo,hi=paired_interval(v,draws); vals_ci[name]=(obs,lo,hi)
            sensitivity.append({'scenario':scenario,'metric':metric,'n':len(subset),'excluded_ids':','.join(sorted(excluded)),
                'Delta_E':vals_ci['Delta_E'][0],'Delta_E_ci_lower':vals_ci['Delta_E'][1],'Delta_E_ci_upper':vals_ci['Delta_E'][2],
                'Delta_G':vals_ci['Delta_G'][0],'Delta_G_ci_lower':vals_ci['Delta_G'][1],'Delta_G_ci_upper':vals_ci['Delta_G'][2],
                'C_minus_B':vals_ci['C_minus_B'][0],'C_minus_B_ci_lower':vals_ci['C_minus_B'][1],'C_minus_B_ci_upper':vals_ci['C_minus_B'][2],
                'C_minus_B_direction_same_as_all':(vals_ci['C_minus_B'][0]>0)==(mean(cross[metric][r['sample_id']]['C_minus_B'] for r in rows)>0)})
    write_csv(OUT/'sensitivity.csv',sensitivity)

    quality_comparisons=[('E_s','l_to_s','s_to_s'),('E_l','l_to_l','s_to_l'),('C_minus_B','l_to_s','s_to_l'),
        ('s_to_s_minus_direct_s','s_to_s','direct_s'),('s_to_l_minus_direct_l','s_to_l','direct_l'),
        ('l_to_s_minus_direct_s','l_to_s','direct_s'),('l_to_l_minus_direct_l','l_to_l','direct_l'),
        ('gold_to_s_minus_direct_s','gold_to_s','direct_s'),('gold_to_l_minus_direct_l','gold_to_l','direct_l'),
        ('direct_l_minus_direct_s','direct_l','direct_s')]
    quality_rows=[]; faith_negative_rows=[]
    for mi,metric in enumerate(METRICS):
        draws=bootstrap_indices(len(rows),BOOTSTRAP,SEED+mi)
        for name,left,right in quality_comparisons:
            deltas=[float(summaries[left][r['sample_id']][metric])-float(summaries[right][r['sample_id']][metric]) for r in rows]
            obs,lo,hi=paired_interval(deltas,draws); dist=stats_distribution(deltas)
            quality_rows.append({'metric':metric,'comparison':name,'left_arm':left,'right_arm':right,'n':len(deltas),
                'mean_difference':obs,'ci_lower':lo,'ci_upper':hi,'median':dist['median'],'q1':dist['q1'],'q3':dist['q3'],
                'positive_n':sum(x>0 for x in deltas),'zero_n':sum(x==0 for x in deltas),'negative_n':sum(x<0 for x in deltas)})
            if metric=='faithfulness' and name.endswith('_minus_direct_s') or metric=='faithfulness' and name.endswith('_minus_direct_l'):
                for i in sorted(range(len(rows)),key=lambda j:(deltas[j],rows[j]['sample_id']))[:10]:
                    sid=rows[i]['sample_id']
                    left_text=gensumm[left][sid]['output']['summary']
                    right_text=gensumm[right][sid]['output']['summary']
                    faith_negative_rows.append({'comparison':name,'sample_id':sid,'dataset':sample_by_id[sid]['dataset'],
                        'faithfulness_difference':deltas[i],'left_faithfulness':summaries[left][sid]['faithfulness'],
                        'right_faithfulness':summaries[right][sid]['faithfulness'],'left_summary_excerpt':left_text[:300],
                        'right_summary_excerpt':right_text[:300]})
    write_csv(OUT/'quality_contrasts.csv',quality_rows)
    write_csv(OUT/'faithfulness_negative_cases.csv',faith_negative_rows)

    # Cases: deterministic extremes, greedy source diversity, both signs; texts copied from existing data/output.
    case_count=5
    def select_extremes(reverse: bool) -> list[str]:
        ordered=sorted(rows,key=lambda r:(cross['completeness'][r['sample_id']]['C_minus_B'],r['sample_id']),reverse=reverse)
        chosen=[]; used=set()
        for r in ordered:
            if r['dataset'] not in used:
                chosen.append(r['sample_id']); used.add(r['dataset'])
                if len(chosen)>=case_count: break
        for r in ordered:
            if len(chosen)>=case_count: break
            if r['sample_id'] not in chosen: chosen.append(r['sample_id'])
        return chosen
    positive_cases=select_extremes(True); negative_cases=select_extremes(False)
    case_lines=['# 正反个例（按预定规则抽取）','',
        '选择规则：以逐样本 completeness 的 C-B 从高到低/低到高排序，各取 5 例；先贪心覆盖不同来源，再按排序补足，sample_id 作确定性并列排序。参考事实及纪要句子来自既有数据/生成缓存，覆盖判断来自既有 match 缓存；未进行新评审。','',
        '正向案例的 C-B 以 0-1 比例表示；表中指标也为 0-1。证据摘录只呈现与案例差异相关的短文本。','']
    for heading,case_ids in [('C-B最正向案例',positive_cases),('C-B最负向案例',negative_cases)]:
        case_lines += [f'## {heading}','']
        for sid in case_ids:
            row=sample_by_id[sid]; fs=row['key_facts']; S=fact_matches['small'][sid]; L=fact_matches['large'][sid]
            q=cross['completeness'][sid]; case_lines += [f'### {sid} | {row["dataset"]} | C-B={q["C_minus_B"]:.4f}','',
                f'gold事实数 {len(fs)}；small覆盖/支持/事实数 {facts["small"][sid]["coverage"]:.3f}/{facts["small"][sid]["support"]:.3f}/{facts["small"][sid]["fact_count"]}；large {facts["large"][sid]["coverage"]:.3f}/{facts["large"][sid]["support"]:.3f}/{facts["large"][sid]["fact_count"]}。','',
                md_table(['组','完整性','简洁性','忠实性'],[[arm,*[fmt(summaries[arm][sid][m],4) for m in METRICS]] for arm in CROSS]),'']
            diff_ids=sorted(summary_matches['l_to_s'][sid]-summary_matches['s_to_l'][sid])[:3]
            diff_ids += [i for i in sorted(summary_matches['s_to_l'][sid]-summary_matches['l_to_s'][sid])[:3] if i not in diff_ids]
            if not diff_ids: diff_ids=sorted((L-S) or (S-L))[:3]
            case_lines.append('关键参考事实与保留情况：')
            for fid in diff_ids:
                retained={arm:(fid in summary_matches[arm][sid]) for arm in CROSS}
                source_quote=source_line_evidence(row['conversation'],fs[fid])
                case_lines.append(f'- gold[{fid}] {fs[fid]}；原文摘录：“{source_quote}”；S覆盖={fid in S}，L覆盖={fid in L}；A/B/C/D保留={retained[A]}/{retained[B]}/{retained[C]}/{retained[D]}。')
            # Existing sentence match alignment, using the same NLTK sentence segmentation.
            case_lines.append('')
            for arm in CROSS:
                text=gensumm[arm][sid]['output']['summary']; sentences=[x.strip() for x in __import__('nltk').sent_tokenize(text) if x.strip()]
                match=load_json(RUN/'evaluation/summaries'/arm/'match'/f'{sid}.json')['output']['matches']
                excerpts=[]
                for fid in diff_ids:
                    aligned=next((x['align_unit_idx'] for x in match if x['fact_idx']==fid),None)
                    if aligned is not None and aligned<len(sentences): excerpts.append(f'gold[{fid}]→“{sentences[aligned][:240]}”')
                case_lines.append(f'- {arm} 纪要保留证据：' + ('；'.join(excerpts) if excerpts else '未保留上述差异事实。'))
            case_lines.append('')
    case_lines += ['## 评审解释限制','', '匹配缓存是基于既有评审模型对“单条参考事实是否被单条候选句完整表达”的判断；不等于无误差的人工金标准。重合/保留仅为描述性流转证据，不构成严格因果中介证明。']
    (OUT/'cases.md').write_text('\n'.join(case_lines)+'\n',encoding='utf-8')

    # Aggregate and audit details.
    source_counts={k:int(v) for k,v in datasets.items()}
    config_paths=[RUN/'experiment.json',RUN/'protocol-snapshot.json',override_path,RUN/'evaluation-format-recovery.json']
    registry_paths=sorted(recovery_dir.glob('**/format-retry.success.json'))+sorted(recovery_dir.glob('**/requests.json'))
    hash_inputs={str(p):sha256(p) for p in config_paths+registry_paths if p.is_file()}
    manifest={'analysis_time_utc':datetime.now(timezone.utc).isoformat(),'status':'completed',
        'analysis_version':'analysis-20261019-offline-01','inputs':{'dataset':str(DATA),'run':str(RUN),'protocol_snapshot':str(RUN/'protocol-snapshot.json'),
            'experiment':str(RUN/'experiment.json'),'manual_summary_overrides':str(override_path),'evaluation_format_recovery':str(RUN/'evaluation-format-recovery.json')},
        'selected_sample_count':len(rows),'unique_sample_ids':len(set(ids)),'source_counts':source_counts,
        'group_record_counts':{'summary_metrics':{a:len(summaries[a]) for a in ARMS},'fact_metrics':{s:len(facts[s]) for s in SOURCES},
            'summary_generation':{a:len(gensumm[a]) for a in ARMS},'fact_generation':{s:len(genfacts[s]) for s in SOURCES}},
        'sha256':{'protocol_snapshot':sha256(RUN/'protocol-snapshot.json'),'experiment':sha256(RUN/'experiment.json'),
            'manual_summary_overrides':sha256(override_path),'evaluation_format_recovery_registry':sha256(RUN/'evaluation-format-recovery.json'),
            'configuration_and_registry_files':hash_inputs,'analysis_script':sha256(Path(__file__))},
        'bootstrap':{'replicates':BOOTSTRAP,'confidence':CONFIDENCE,'seed':SEED,'method':'paired percentile; random.Random(seed); lower index floor(tail*R), upper index floor((1-tail)*R)-1, matching report.py'},
        'text_metrics':{'sentence_count':'nltk.sent_tokenize, same rule as evaluate.py','word_count':r"Unicode regex \b[\w]+(?:['’][\w]+)*\b; internal apostrophes count within token",'character_count':'Python len(summary) Unicode code points'},
        'integrity':{'evaluation_requested':status['requested'],'evaluation_failures':status['failures'],'exact_tolerance':TOL},
        'exception_ids':{'manual_override':sorted(override_ids),'format_retry':sorted(recovery_ids)}}
    write_json(OUT/'manifest.json',manifest)

    # Core tables for report.
    def effect(metric: str, name: str) -> dict[str, Any]: return next(x for x in effects if x['metric']==metric and x['effect']==name)
    ci=lambda e:f"{e['mean']*100:.2f} pp [{e['ci_lower']*100:.2f}, {e['ci_upper']*100:.2f}]"
    comp_rows=[[name,ci(effect('completeness',name)),f"+{effect('completeness',name)['positive_n']}/0={effect('completeness',name)['zero_n']}/-{effect('completeness',name)['negative_n']}"] for name in ('E_s','E_l','Delta_E','G_s','G_l','Delta_G','C_minus_B','Delta_E_minus_Delta_G')]
    source_rows=[]
    for ds in sorted(datasets):
        x=next(z for z in by_source if z['dataset']==ds and z['metric']=='completeness')
        source_rows.append([ds,x['n'],f"{x['mean_s_to_s']:.3f}/{x['mean_s_to_l']:.3f}/{x['mean_l_to_s']:.3f}/{x['mean_l_to_l']:.3f}",
            f"{x['Delta_E_mean']*100:.2f}",f"{x['Delta_G_mean']*100:.2f}",f"{x['C_minus_B_mean']*100:.2f} [{x['C_minus_B_ci_lower']*100:.2f},{x['C_minus_B_ci_upper']*100:.2f}]"])
    gaps=[]
    for x in gap_rows:
        gaps.append([x['condition'],f"{x['small_mean']:.4f}",f"{x['large_mean']:.4f}",f"{x['absolute_gap_large_minus_small']*100:.2f} pp",f"{x['relative_gap_over_small']*100:.2f}%",fmt(x.get('absolute_gap_shrink_vs_direct',0)*100)+' pp' if x['condition']!='direct' else '基准'])
    length_quality=[]
    for name, left, right in length_comparisons:
        c=effect('completeness','C_minus_B') if name=='C_minus_B' else None
        if name=='C_minus_B': comp=effect('completeness','C_minus_B')['mean']
        elif name=='E_s': comp=effect('completeness','E_s')['mean']
        elif name=='E_l': comp=effect('completeness','E_l')['mean']
        else: comp=mean(float(summaries[left][r['sample_id']]['completeness'])-float(summaries[right][r['sample_id']]['completeness']) for r in rows)
        le=next((x for x in length_effects if x['measurement']=='words' and x['comparison']==name),None)
        length_quality.append([name,f'{comp*100:.2f} pp',f"{le['left_minus_right']:.1f} words [{le['ci_lower']:.1f},{le['ci_upper']:.1f}]" if le else 'NA'])
    flowby={x['measure']:x for x in flow_summary}
    flowlines=[]
    for dim in flow_dimensions:
        x=flowby[dim]
        flowlines.append([dim,x['meetings_applicable'],x['meetings_not_applicable_denominator_zero'],f"{x['meeting_average_rate']:.3f}" if x['meeting_average_rate'] is not None else 'N/A',f"{x['pooled_numerator']}/{x['pooled_denominator']} ({x['pooled_rate']:.3f})" if x['pooled_denominator'] else 'N/A'])
    quality_lookup={(x['metric'],x['comparison']):x for x in quality_rows}
    assisted_faith_rows=[]
    for name in ('s_to_s_minus_direct_s','l_to_s_minus_direct_s','gold_to_s_minus_direct_s',
                 's_to_l_minus_direct_l','l_to_l_minus_direct_l','gold_to_l_minus_direct_l'):
        x=quality_lookup[('faithfulness',name)]
        assisted_faith_rows.append([name,f"{x['mean_difference']*100:.2f} pp [{x['ci_lower']*100:.2f},{x['ci_upper']*100:.2f}]",
            f"+{x['positive_n']}/0={x['zero_n']}/-{x['negative_n']}"])
    sensitivity_report=[]
    for scenario in ('all_300','exclude_manual_override','exclude_format_retry','exclude_union'):
        x=next(x for x in sensitivity if x['scenario']==scenario and x['metric']=='completeness')
        sensitivity_report.append([scenario,x['n'],x['excluded_ids'] or '无',
            f"{x['C_minus_B']*100:.2f} [{x['C_minus_B_ci_lower']*100:.2f},{x['C_minus_B_ci_upper']*100:.2f}]",
            f"{x['Delta_E']*100:.2f} [{x['Delta_E_ci_lower']*100:.2f},{x['Delta_E_ci_upper']*100:.2f}]",
            f"{x['Delta_G']*100:.2f} [{x['Delta_G_ci_lower']*100:.2f},{x['Delta_G_ci_upper']*100:.2f}]",
            'same' if x['C_minus_B_direction_same_as_all'] else 'changed'])
    fact_source_coverage=[]
    for dataset in sorted(datasets):
        vals=[]
        for src in SOURCES:
            x=next(x for x in fact_source_rows if x['dataset']==dataset and x['source']==src and x['metric']=='coverage')
            vals.append(f"{src} {x['mean']:.3f}")
        fact_source_coverage.append([dataset,datasets[dataset],*vals])
    gap_sequence=[gap_by[x]['absolute_gap_large_minus_small'] for x in ('direct','small_facts','large_facts','gold')]
    gap_monotonic=all(gap_sequence[i+1] <= gap_sequence[i] for i in range(len(gap_sequence)-1))

    # Human-readable report with explicit inferential boundaries.
    report=['# exp04-2gpu：300条会议离线复核分析','',f"分析目录：`{OUT}`。主分析样本按 `splits` 含 `all` 选择，n={len(rows)}；五来源计数：{', '.join(f'{k} {v}' for k,v in sorted(source_counts.items()))}。","",
        '## 1. 原先提出的核心假设和判断标准','',
        '研究问题是：改善关键事实提取/内容选择，相对于升级下游生成模型，是否是提升关键事实完整性的更主要可干预因素；以及完整性收益是否伴随简洁性或忠实性代价。主要检验指标预先按问题指定为 completeness；conciseness 与 faithfulness 是质量权衡指标，不合成为未经定义的总分。A=s_to_s、B=s_to_l、C=l_to_s、D=l_to_l。正值代表左式减右式更高；效应以0—1比例计算，正文 pp 为百分点。区间为会议配对百分位 bootstrap（2000次，seed=42）。','',
        '输入完整性通过：evaluation-status 为 requested=3000、failures=[]；八组×300 条纪要指标、两提取器×300 条事实指标，以及对应生成和 match 缓存均为可读的 ok 记录。源 CSV 均值、项目已有配对差值/区间按 report.py 算法重算，容差 1e-10；详见 paired_effects.csv 与脚本完整性门槛。','',
        '## 2. 核心交叉比较及不确定性','',md_table(['效应（completeness）','均值及95%区间','逐样本正/零/负'],comp_rows),'',
        (f"关键代数关系逐样本成立：Delta_E-Delta_G 与 C-B 最大绝对误差不超过 1e-12；总体均值也一致（{effect('completeness','Delta_E_minus_Delta_G')['mean']:.12g} 对 {effect('completeness','C_minus_B')['mean']:.12g}）。"
         f"C-B 是固定生成器/事实组合交叉比较，不是单独的“事实提取器主效应”。300 条宏平均为主结果。五来源等权描述值（改变来源权重，不能代替主结果）：completeness Delta_E={equal_source['completeness']['Delta_E']*100:.2f} pp，Delta_G={equal_source['completeness']['Delta_G']*100:.2f} pp，C-B={equal_source['completeness']['C_minus_B']*100:.2f} pp。"),'',
        '来源内均值和探索性区间见 by_source.csv；这些 n 较小，区间用于描述，不把同向均值解释为每个来源分别显著。','',
        '## 3. 事实质量差异与流转证据','',
        (f"总体small→large：coverage {paired_fact[0]['large_minus_small']*100:.2f} pp [{paired_fact[0]['ci_lower']*100:.2f},{paired_fact[0]['ci_upper']*100:.2f}]；"
         f"support {paired_fact[1]['large_minus_small']*100:.2f} pp [{paired_fact[1]['ci_lower']*100:.2f},{paired_fact[1]['ci_upper']*100:.2f}]；"
         f"事实数 {paired_fact[2]['large_minus_small']:.2f} 条 [{paired_fact[2]['ci_lower']:.2f},{paired_fact[2]['ci_upper']:.2f}]；"
         f"字符数 {paired_fact[3]['large_minus_small']:.1f} [{paired_fact[3]['ci_lower']:.1f},{paired_fact[3]['ci_upper']:.1f}]。"),'',
        md_table(['来源','n','small coverage','large coverage'],fact_source_coverage),'',
        '提取质量的测量边界：coverage 是 gold 关键事实被候选事实列表完整表达的比例；support 是候选事实中被判定受原文支持的比例。二者都不等同于 salience precision，也不覆盖事实选择质量的全部。事实条数和字符数只表示输出量。逐样本分布、配对差值和 bootstrap 区间见 fact_quality_summary.csv、fact_quality_paired.csv；精确字符串重复见 duplicate_cases.csv。',
        "small≤5条事实诊断组 n=" + str(len(few_fact_ids)) + "，ID：" + (", ".join(few_fact_ids) or "无") + "。small 每样本重复出现≥3次诊断组 n=" + str(len(repeat_ids)) + "，ID：" + (", ".join(repeat_ids) or "无") + "。两组均保留在主分析。32B覆盖变化与条数/字符数变化的描述相关性及共同增加计数见 fact_volume_association.json。",'',
        '使用既有 match 缓存形成 gold 事实 ID 集合。L\\S额外覆盖参考事实在 C/D/A/B 中的保留统计，同时报告会议平均率和合并分子/分母；分母为零会议按不适用而非零处理：','',md_table(['结果组','适用会议','分母零会议','会议平均率','合并比例'],flowlines),'',
        'fact_flow.csv 逐样本给出 S、L、T 集合 ID、交并差计数，并对每个辅助纪要记录“事实列表未覆盖但纪要覆盖”及“列表覆盖但纪要未覆盖”。按来源的额外事实保留情况见 fact_flow_by_source.csv。匹配为评审模型描述性判断，不能单凭集合重合宣称因果中介。','',
        '## 4. 简洁性、忠实性、长度的权衡','',
        md_table(['事实条件','8B完整性均值','32B完整性均值','生成器绝对差距','相对差距（/8B）','相对direct绝对缩差'],gaps),'',
        (f"direct→gold绝对生成器差距收缩 {gap_by['gold']['absolute_gap_shrink_vs_direct']*100:.2f} pp "
         f"[ {gap_by['gold']['absolute_shrink_ci_lower']*100:.2f}, {gap_by['gold']['absolute_shrink_ci_upper']*100:.2f} ]；"
         f"相对差距从 {gap_by['direct']['relative_gap_over_small']*100:.2f}% 降至 {gap_by['gold']['relative_gap_over_small']*100:.2f}%，"
         f"收缩 {gap_by['gold']['relative_gap_shrink_vs_direct']*100:.2f} 个百分点 "
         f"[{gap_by['gold']['relative_shrink_ci_lower']*100:.2f},{gap_by['gold']['relative_shrink_ci_upper']*100:.2f}]。"
         f"绝对差距沿 direct→small事实→large事实→gold 是否单调收缩：{'是' if gap_monotonic else '否'}。"),'',
        (f"核心 C-B 的 conciseness 差为 {effect('conciseness','C_minus_B')['mean']*100:.2f} pp "
         f"[{effect('conciseness','C_minus_B')['ci_lower']*100:.2f},{effect('conciseness','C_minus_B')['ci_upper']*100:.2f}]；"
         f"faithfulness 差为 {effect('faithfulness','C_minus_B')['mean']*100:.2f} pp "
         f"[{effect('faithfulness','C_minus_B')['ci_lower']*100:.2f},{effect('faithfulness','C_minus_B')['ci_upper']*100:.2f}]。"),'',
        md_table(['事实辅助相对对应direct：faithfulness','配对差及95%区间','正/零/负'],assisted_faith_rows),'',
        '忠实性负向变化最明显的逐样本案例（每种事实辅助/direct配对列最负10例，含摘要摘录）见 faithfulness_negative_cases.csv；完整逐样本差值见 quality_contrasts.csv。','',
        '纪要长度包括 Python Unicode 字符数、统一正则词数（Unicode `\\w` 连续序列，内部撇号留在词内）、项目 NLTK `sent_tokenize` 句数、既有 atomic_fact_count 和 completion_tokens。sentence_count 与 evaluate.py 规则逐条核对；usage 缺失量列于 length_distributions.csv。',
        '长度比较及完整性收益并列如下；这是描述性诊断，不能据此断言完整性差异由长度造成：','',md_table(['比较','完整性差','词数差及95%区间'],length_quality),'',
        '各组长度分布见 length_distributions.csv；字符、词、句、原子事实数和 completion tokens 的配对差见 length_effects.csv。paired_effects.csv 同时列出三个指标的 E_s、E_l、Delta_E、G_s、G_l、Delta_G、C-B、代数一致项，以及中位数/IQR和正零负样本数。','',
        '直接生成与事实辅助的忠实性差值需结合 paired_effects.csv 中相应比较（包含原报告差值）以及逐样本变化阅读；固定生成器升级事实来源可比较 E_s/E_l 的 faithfulness。均值仍高不代表没有代价；也不以单个很小的统计差异自动判定实际不可接受。正反极端个例见 cases.md。','',
        '## 5. 来源差异、反例和敏感性','',md_table(['来源','n','A/B/C/D完整性均值','Delta_E pp','Delta_G pp','C-B pp及探索性95%区间'],source_rows),'',
        '按来源和 C-B 正/零/负分组的额外事实保留率见 fact_flow_by_source_gain.csv；来源内小样本区间均为探索性。','',
        '协议例外按登记文件读取：manual override IDs = '+(', '.join(sorted(override_ids)) or '无')+'；成功格式重试 IDs = '+(', '.join(sorted(recovery_ids)) or '无')+'。主结果保留全部300条。','',
        md_table(['敏感性场景','n','排除ID','C-B pp [95%区间]','Delta_E pp [95%区间]','Delta_G pp [95%区间]','方向'],sensitivity_report),'',
        '预先点名的讨论样本逐条复核结果见 named_samples.csv；正反 C-B 极值案例见 cases.md。诊断分组均保留在主分析。','',
        '## 6. 当前证据支持到哪一步、没有支持哪一步','',
        ("本实验的配对干预比较估计：在这批会议、现有提示与生成设置下，替换输入事实列表与切换生成模型对应的 completeness 差异。C-B 均值为 " + ("%.2f" % (effect("completeness", "C_minus_B")["mean"]*100)) + " pp，95%区间 [" + ("%.2f" % (effect("completeness", "C_minus_B")["ci_lower"]*100)) + ", " + ("%.2f" % (effect("completeness", "C_minus_B")["ci_upper"]*100)) + "] pp；Delta_E 与 Delta_G 区间见上表。它不证明模型内部能力的完整因果来源，不证明所有数据分布/训练设置均如此，也不证明生成器等效。Gold 是参考事实辅助条件，不是真实强提取器；gap 缩小与完全等效是不同主张，且本报告未设事后等效阈值。",'',
        '## 7. 对后续训练与迁移的启示','',
        '结果应引导后续实验把“小模型的事实选择能力”作为可训练、可测量的对象：以独立参考事实匹配和原文支持分开监控覆盖与支持，同时保留条数、字符数、重复率及下游流转。随后在固定生成器下检验训练前后事实选择对纪要完整性、简洁性、忠实性的影响，并加入 direct 生成作为迁移检验；在训练/评估会议和来源上隔离，预先定义主要指标、抽样与等效界限，避免将 gold 辅助条件误读为真实模型表现。','',
        '## 附件与复核','',
        '脚本：analyze_exp04.py。逐样本文件：per_sample_arms.csv、per_sample_facts.csv、per_sample_cross.csv。汇总：paired_effects.csv、by_source.csv、gap_analysis.csv、fact_flow.csv、sensitivity.csv、cases.md。其他支持表均保存在同目录。报告复算原 CSV 时要求绝对误差≤1e-10；CSV 按 UTF-8 BOM 兼容读取.')]
    report = [part for item in report for part in (item if isinstance(item, tuple) else (item,))]
    (OUT/'analysis_report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')

    # Re-read every required deliverable and enforce output dimensions and algebra.
    required={'per_sample_arms.csv':len(rows)*len(ARMS),'per_sample_facts.csv':len(rows)*2,'per_sample_cross.csv':len(rows),
              'paired_effects.csv':len(effects),'by_source.csv':len(by_source),'gap_analysis.csv':len(gap_rows),
              'fact_flow.csv':len(rows),'sensitivity.csv':len(sensitivity),
              'fact_quality_by_source.csv':len(datasets)*len(SOURCES)*5,
              'fact_flow_by_source.csv':len(datasets)*len(flow_dimensions),
              'fact_flow_by_source_gain.csv':len(datasets)*3*len(flow_dimensions),
              'quality_contrasts.csv':len(METRICS)*len(quality_comparisons),
              'faithfulness_negative_cases.csv':len(faith_negative_rows),
              'named_samples.csv':len(named_rows),'diagnostic_impact.csv':len(diagnostic_rows)}
    validation=[]
    for filename,expected in required.items():
        reread=read_csv(OUT/filename)
        if len(reread)!=expected: validation.append(f'{filename}: rows={len(reread)}, expected={expected}')
    for fn in ('manifest.json','analysis_report.md','cases.md','protocol_exceptions.json','diagnostic_groups.json',
               'fact_volume_association.json'):
        if not (OUT/fn).is_file() or not (OUT/fn).stat().st_size: validation.append(f'{fn}: missing or empty')
    reread_cross=read_csv(OUT/'per_sample_cross.csv')
    for r in reread_cross:
        for metric in METRICS:
            if abs((float(r[f'{metric}_Delta_E'])-float(r[f'{metric}_Delta_G']))-float(r[f'{metric}_C_minus_B']))>1e-12:
                validation.append(f"algebra reread failed: {r['sample_id']}/{metric}")
    # Source-specific directions and sensitivity summary in machine-readable acceptance record.
    validation_obj={'status':'passed' if not validation else 'failed','selected_n':len(rows),'source_counts':source_counts,
        'row_counts':required,'algebra_max_abs_error':max(abs((cross[m][sid]['Delta_E']-cross[m][sid]['Delta_G'])-cross[m][sid]['C_minus_B']) for m in METRICS for sid in sample_by_id),
        'source_C_minus_B_directions':{r['dataset']:('positive' if r['C_minus_B_mean']>0 else 'negative' if r['C_minus_B_mean']<0 else 'zero') for r in by_source if r['metric']=='completeness'},
        'sensitivity_direction':{r['scenario']:r['C_minus_B_direction_same_as_all'] for r in sensitivity if r['metric']=='completeness'},
        'validation_errors':validation}
    write_json(OUT/'validation.json',validation_obj)
    if validation:
        print('\n'.join(validation),file=sys.stderr); return 3
    print(json.dumps({'analysis_dir':str(OUT),'validation':'passed','n':len(rows),'source_counts':source_counts,
        'completeness_C_minus_B':effect('completeness','C_minus_B'),'completeness_Delta_E':effect('completeness','Delta_E'),
        'completeness_Delta_G':effect('completeness','Delta_G'),'gap_direct':gap_by['direct'],'gap_gold':gap_by['gold'],
        'source_directions':validation_obj['source_C_minus_B_directions'],'sensitivity_direction':validation_obj['sensitivity_direction']},ensure_ascii=False,indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
