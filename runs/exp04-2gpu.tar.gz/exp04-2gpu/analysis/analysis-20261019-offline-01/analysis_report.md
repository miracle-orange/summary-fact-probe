# exp04-2gpu：300条会议离线复核分析

分析目录：`/home/ma-user/work/dataset/summary-fact-probe/runs/exp04-2gpu/analysis/analysis-20261019-offline-01`。主分析样本按 `splits` 含 `all` 选择，n=300；五来源计数：ECTSum 75, MeetingBank 75, QMSum-Academic 50, QMSum-Committee 30, QMSum-Product 70。

## 1. 原先提出的核心假设和判断标准

研究问题是：改善关键事实提取/内容选择，相对于升级下游生成模型，是否是提升关键事实完整性的更主要可干预因素；以及完整性收益是否伴随简洁性或忠实性代价。主要检验指标预先按问题指定为 completeness；conciseness 与 faithfulness 是质量权衡指标，不合成为未经定义的总分。A=s_to_s、B=s_to_l、C=l_to_s、D=l_to_l。正值代表左式减右式更高；效应以0—1比例计算，正文 pp 为百分点。区间为会议配对百分位 bootstrap（2000次，seed=42）。

输入完整性通过：evaluation-status 为 requested=3000、failures=[]；八组×300 条纪要指标、两提取器×300 条事实指标，以及对应生成和 match 缓存均为可读的 ok 记录。源 CSV 均值、项目已有配对差值/区间按 report.py 算法重算，容差 1e-10；详见 paired_effects.csv 与脚本完整性门槛。

## 2. 核心交叉比较及不确定性

| 效应（completeness） | 均值及95%区间 | 逐样本正/零/负 |
| --- | --- | --- |
| E_s | 6.52 pp [4.41, 8.63] | +176/0=35/-89 |
| E_l | 7.49 pp [5.66, 9.41] | +184/0=38/-78 |
| Delta_E | 7.01 pp [5.41, 8.64] | +196/0=14/-90 |
| G_s | 1.61 pp [-0.22, 3.36] | +137/0=50/-113 |
| G_l | 2.58 pp [0.68, 4.43] | +132/0=57/-111 |
| Delta_G | 2.10 pp [0.63, 3.50] | +153/0=30/-117 |
| C_minus_B | 4.91 pp [2.82, 6.98] | +156/0=42/-102 |
| Delta_E_minus_Delta_G | 4.91 pp [2.82, 6.98] | +156/0=42/-102 |

关键代数关系逐样本成立：Delta_E-Delta_G 与 C-B 最大绝对误差不超过 1e-12；总体均值也一致（0.0490909113279 对 0.0490909113279）。C-B 是固定生成器/事实组合交叉比较，不是单独的“事实提取器主效应”。300 条宏平均为主结果。五来源等权描述值（改变来源权重，不能代替主结果）：completeness Delta_E=6.94 pp，Delta_G=2.63 pp，C-B=4.31 pp。

来源内均值和探索性区间见 by_source.csv；这些 n 较小，区间用于描述，不把同向均值解释为每个来源分别显著。

## 3. 事实质量差异与流转证据

总体small→large：coverage 16.65 pp [13.99,19.47]；support 3.92 pp [2.82,5.06]；事实数 4.49 条 [2.96,6.15]；字符数 369.7 [201.3,549.7]。

| 来源 | n | small coverage | large coverage |
| --- | --- | --- | --- |
| ECTSum | 75 | small 0.635 | large 0.810 |
| MeetingBank | 75 | small 0.539 | large 0.705 |
| QMSum-Academic | 50 | small 0.464 | large 0.603 |
| QMSum-Committee | 30 | small 0.426 | large 0.644 |
| QMSum-Product | 70 | small 0.611 | large 0.767 |

提取质量的测量边界：coverage 是 gold 关键事实被候选事实列表完整表达的比例；support 是候选事实中被判定受原文支持的比例。二者都不等同于 salience precision，也不覆盖事实选择质量的全部。事实条数和字符数只表示输出量。逐样本分布、配对差值和 bootstrap 区间见 fact_quality_summary.csv、fact_quality_paired.csv；精确字符串重复见 duplicate_cases.csv。
small≤5条事实诊断组 n=34，ID：meeting-0048, meeting-0051, meeting-0078, meeting-0234, meeting-0290, meeting-0358, meeting-0392, meeting-0420, meeting-0571, meeting-0639, meeting-0653, meeting-0693, meeting-0696, meeting-0749, meeting-0761, meeting-0790, meeting-0791, meeting-0825, meeting-0836, meeting-0994, meeting-1126, meeting-1166, meeting-1193, meeting-1281, meeting-1317, meeting-1322, meeting-1365, meeting-1423, meeting-1463, meeting-1692, meeting-1696, meeting-1719, meeting-1725, meeting-1776。small 每样本重复出现≥3次诊断组 n=2，ID：meeting-0341, meeting-1164。两组均保留在主分析。32B覆盖变化与条数/字符数变化的描述相关性及共同增加计数见 fact_volume_association.json。

使用既有 match 缓存形成 gold 事实 ID 集合。L\S额外覆盖参考事实在 C/D/A/B 中的保留统计，同时报告会议平均率和合并分子/分母；分母为零会议按不适用而非零处理：

| 结果组 | 适用会议 | 分母零会议 | 会议平均率 | 合并比例 |
| --- | --- | --- | --- | --- |
| L_extra_retained_l_to_s | 286 | 14 | 0.721 | 1018/1476 (0.690) |
| L_extra_retained_l_to_l | 286 | 14 | 0.733 | 1079/1476 (0.731) |
| L_extra_retained_s_to_s | 286 | 14 | 0.197 | 322/1476 (0.218) |
| L_extra_retained_s_to_l | 286 | 14 | 0.283 | 438/1476 (0.297) |

fact_flow.csv 逐样本给出 S、L、T 集合 ID、交并差计数，并对每个辅助纪要记录“事实列表未覆盖但纪要覆盖”及“列表覆盖但纪要未覆盖”。按来源的额外事实保留情况见 fact_flow_by_source.csv。匹配为评审模型描述性判断，不能单凭集合重合宣称因果中介。

## 4. 简洁性、忠实性、长度的权衡

| 事实条件 | 8B完整性均值 | 32B完整性均值 | 生成器绝对差距 | 相对差距（/8B） | 相对direct绝对缩差 |
| --- | --- | --- | --- | --- | --- |
| direct | 0.3825 | 0.4583 | 7.59 pp | 19.84% | 基准 |
| small_facts | 0.5505 | 0.5666 | 1.61 pp | 2.93% | 5.973682 pp |
| large_facts | 0.6157 | 0.6415 | 2.58 pp | 4.19% | 5.004899 pp |
| gold | 0.7552 | 0.8063 | 5.12 pp | 6.78% | 2.468597 pp |

direct→gold绝对生成器差距收缩 2.47 pp [ 1.88, 2.95 ]；相对差距从 19.84% 降至 6.78%，收缩 13.06 个百分点 [8.71,17.47]。绝对差距沿 direct→small事实→large事实→gold 是否单调收缩：否。

核心 C-B 的 conciseness 差为 -4.99 pp [-7.00,-3.14]；faithfulness 差为 1.04 pp [0.37,1.72]。

| 事实辅助相对对应direct：faithfulness | 配对差及95%区间 | 正/零/负 |
| --- | --- | --- |
| s_to_s_minus_direct_s | -1.30 pp [-1.93,-0.67] | +77/0=92/-131 |
| l_to_s_minus_direct_s | -0.74 pp [-1.33,-0.13] | +76/0=105/-119 |
| gold_to_s_minus_direct_s | -0.95 pp [-1.67,-0.23] | +79/0=116/-105 |
| s_to_l_minus_direct_l | -2.05 pp [-2.73,-1.40] | +63/0=99/-138 |
| l_to_l_minus_direct_l | -1.28 pp [-1.97,-0.60] | +76/0=90/-134 |
| gold_to_l_minus_direct_l | -0.91 pp [-1.52,-0.27] | +78/0=114/-108 |

忠实性负向变化最明显的逐样本案例（每种事实辅助/direct配对列最负10例，含摘要摘录）见 faithfulness_negative_cases.csv；完整逐样本差值见 quality_contrasts.csv。

纪要长度包括 Python Unicode 字符数、统一正则词数（Unicode `\w` 连续序列，内部撇号留在词内）、项目 NLTK `sent_tokenize` 句数、既有 atomic_fact_count 和 completion_tokens。sentence_count 与 evaluate.py 规则逐条核对；usage 缺失量列于 length_distributions.csv。
长度比较及完整性收益并列如下；这是描述性诊断，不能据此断言完整性差异由长度造成：

| 比较 | 完整性差 | 词数差及95%区间 |
| --- | --- | --- |
| E_s | 6.52 pp | 16.5 words [2.6,29.8] |
| E_l | 7.49 pp | 30.5 words [22.2,39.4] |
| C_minus_B | 4.91 pp | 49.2 words [38.7,60.3] |
| gold_vs_direct_small | 37.27 pp | 81.2 words [76.1,86.5] |
| gold_vs_direct_large | 34.80 pp | 62.7 words [56.0,69.4] |

各组长度分布见 length_distributions.csv；字符、词、句、原子事实数和 completion tokens 的配对差见 length_effects.csv。paired_effects.csv 同时列出三个指标的 E_s、E_l、Delta_E、G_s、G_l、Delta_G、C-B、代数一致项，以及中位数/IQR和正零负样本数。

直接生成与事实辅助的忠实性差值需结合 paired_effects.csv 中相应比较（包含原报告差值）以及逐样本变化阅读；固定生成器升级事实来源可比较 E_s/E_l 的 faithfulness。均值仍高不代表没有代价；也不以单个很小的统计差异自动判定实际不可接受。正反极端个例见 cases.md。

## 5. 来源差异、反例和敏感性

| 来源 | n | A/B/C/D完整性均值 | Delta_E pp | Delta_G pp | C-B pp及探索性95%区间 |
| --- | --- | --- | --- | --- | --- |
| ECTSum | 75 | 0.578/0.581/0.652/0.681 | 8.68 | 1.59 | 7.08 [3.37,11.30] |
| MeetingBank | 75 | 0.571/0.590/0.627/0.628 | 4.71 | 1.01 | 3.70 [0.37,6.99] |
| QMSum-Academic | 50 | 0.466/0.490/0.516/0.571 | 6.56 | 3.96 | 2.60 [-2.88,8.42] |
| QMSum-Committee | 30 | 0.396/0.425/0.434/0.518 | 6.55 | 5.60 | 0.95 [-6.49,7.91] |
| QMSum-Product | 70 | 0.625/0.641/0.713/0.717 | 8.19 | 0.97 | 7.22 [3.78,11.17] |

按来源和 C-B 正/零/负分组的额外事实保留率见 fact_flow_by_source_gain.csv；来源内小样本区间均为探索性。

协议例外按登记文件读取：manual override IDs = meeting-1707；成功格式重试 IDs = meeting-0675, meeting-1009, meeting-1463, meeting-1505, meeting-1509。主结果保留全部300条。

| 敏感性场景 | n | 排除ID | C-B pp [95%区间] | Delta_E pp [95%区间] | Delta_G pp [95%区间] | 方向 |
| --- | --- | --- | --- | --- | --- | --- |
| all_300 | 300 | 无 | 4.91 [2.82,6.98] | 7.01 [5.41,8.64] | 2.10 [0.63,3.50] | same |
| exclude_manual_override | 299 | meeting-1707 | 4.99 [2.89,7.05] | 7.06 [5.40,8.68] | 2.07 [0.61,3.50] | same |
| exclude_format_retry | 295 | meeting-0675,meeting-1009,meeting-1463,meeting-1505,meeting-1509 | 4.84 [2.78,6.90] | 7.00 [5.38,8.76] | 2.16 [0.83,3.56] | same |
| exclude_union | 294 | meeting-0675,meeting-1009,meeting-1463,meeting-1505,meeting-1509,meeting-1707 | 4.93 [2.81,6.96] | 7.06 [5.43,8.80] | 2.13 [0.82,3.51] | same |

预先点名的讨论样本逐条复核结果见 named_samples.csv；正反 C-B 极值案例见 cases.md。诊断分组均保留在主分析。

## 6. 当前证据支持到哪一步、没有支持哪一步

本实验的配对干预比较估计：在这批会议、现有提示与生成设置下，替换输入事实列表与切换生成模型对应的 completeness 差异。C-B 均值为 4.91 pp，95%区间 [2.82, 6.98] pp；Delta_E 与 Delta_G 区间见上表。它不证明模型内部能力的完整因果来源，不证明所有数据分布/训练设置均如此，也不证明生成器等效。Gold 是参考事实辅助条件，不是真实强提取器；gap 缩小与完全等效是不同主张，且本报告未设事后等效阈值。

## 7. 对后续训练与迁移的启示

结果应引导后续实验把“小模型的事实选择能力”作为可训练、可测量的对象：以独立参考事实匹配和原文支持分开监控覆盖与支持，同时保留条数、字符数、重复率及下游流转。随后在固定生成器下检验训练前后事实选择对纪要完整性、简洁性、忠实性的影响，并加入 direct 生成作为迁移检验；在训练/评估会议和来源上隔离，预先定义主要指标、抽样与等效界限，避免将 gold 辅助条件误读为真实模型表现。

## 附件与复核

脚本：analyze_exp04.py。逐样本文件：per_sample_arms.csv、per_sample_facts.csv、per_sample_cross.csv。汇总：paired_effects.csv、by_source.csv、gap_analysis.csv、fact_flow.csv、sensitivity.csv、cases.md。其他支持表均保存在同目录。报告复算原 CSV 时要求绝对误差≤1e-10；CSV 按 UTF-8 BOM 兼容读取.
