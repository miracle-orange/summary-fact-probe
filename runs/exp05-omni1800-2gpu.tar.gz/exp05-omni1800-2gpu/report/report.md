# Generic meeting fact-intervention report

## Summary metrics (macro average)

| Arm | N | Completeness | Conciseness | Faithfulness |
|---|---:|---:|---:|---:|
| direct_s | 18 | 0.5394 | 0.6769 | 0.9393 |
| direct_l | 18 | 0.6052 | 0.7923 | 0.9785 |
| s_to_s | 18 | 0.7144 | 0.7940 | 0.9055 |
| s_to_l | 18 | 0.7055 | 0.7825 | 0.9150 |
| l_to_s | 18 | 0.7351 | 0.8727 | 0.9272 |
| l_to_l | 18 | 0.8276 | 0.7779 | 0.9409 |
| gold_to_s | 18 | 0.8880 | 0.9291 | 0.9815 |
| gold_to_l | 18 | 0.8953 | 0.9059 | 0.9598 |

## Paired contrasts

Percentile bootstrap intervals use 2000 paired resamples.

| Contrast | Metric | N | Difference | CI |
|---|---|---:|---:|---:|
| direct_l - direct_s | completeness | 18 | 0.0658 | [0.0038, 0.1229] |
| direct_l - direct_s | conciseness | 18 | 0.1155 | [0.0523, 0.1803] |
| direct_l - direct_s | faithfulness | 18 | 0.0392 | [-0.0146, 0.0835] |
| s_to_s - direct_s | completeness | 18 | 0.1750 | [0.0883, 0.2654] |
| s_to_s - direct_s | conciseness | 18 | 0.1172 | [0.0274, 0.2191] |
| s_to_s - direct_s | faithfulness | 18 | -0.0338 | [-0.1000, 0.0210] |
| l_to_s - s_to_s | completeness | 18 | 0.0208 | [-0.0414, 0.0873] |
| l_to_s - s_to_s | conciseness | 18 | 0.0787 | [0.0383, 0.1227] |
| l_to_s - s_to_s | faithfulness | 18 | 0.0217 | [-0.0130, 0.0591] |
| l_to_s - direct_s | completeness | 18 | 0.1957 | [0.1253, 0.2706] |
| l_to_s - direct_s | conciseness | 18 | 0.1959 | [0.1050, 0.3039] |
| l_to_s - direct_s | faithfulness | 18 | -0.0121 | [-0.0646, 0.0345] |
| gold_to_l - gold_to_s | completeness | 18 | 0.0073 | [-0.0331, 0.0411] |
| gold_to_l - gold_to_s | conciseness | 18 | -0.0232 | [-0.0926, 0.0391] |
| gold_to_l - gold_to_s | faithfulness | 18 | -0.0217 | [-0.0456, 0.0009] |
| s_to_l - l_to_l | completeness | 18 | -0.1221 | [-0.1866, -0.0584] |
| s_to_l - l_to_l | conciseness | 18 | 0.0046 | [-0.0708, 0.0816] |
| s_to_l - l_to_l | faithfulness | 18 | -0.0259 | [-0.0560, 0.0077] |

These are diagnostic associations under fact-list intervention. They do not by themselves prove that fact selection explains the entire model-scale gap.
