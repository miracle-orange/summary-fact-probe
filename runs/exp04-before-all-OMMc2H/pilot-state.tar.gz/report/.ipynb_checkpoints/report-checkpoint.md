# Generic meeting fact-intervention report

## Summary metrics (macro average)

| Arm | N | Completeness | Conciseness | Faithfulness |
|---|---:|---:|---:|---:|
| direct_s | 30 | 0.3941 | 0.6625 | 0.9762 |
| direct_l | 30 | 0.4861 | 0.7316 | 0.9807 |
| s_to_s | 30 | 0.5303 | 0.6762 | 0.9583 |
| s_to_l | 30 | 0.5656 | 0.7159 | 0.9553 |
| l_to_s | 30 | 0.5382 | 0.6381 | 0.9626 |
| l_to_l | 30 | 0.5905 | 0.6842 | 0.9575 |
| gold_to_s | 30 | 0.7450 | 0.8882 | 0.9599 |
| gold_to_l | 30 | 0.7634 | 0.8523 | 0.9697 |

## Paired contrasts

Percentile bootstrap intervals use 2000 paired resamples.

| Contrast | Metric | N | Difference | CI |
|---|---|---:|---:|---:|
| direct_l - direct_s | completeness | 30 | 0.0920 | [0.0165, 0.1690] |
| direct_l - direct_s | conciseness | 30 | 0.0690 | [-0.0168, 0.1637] |
| direct_l - direct_s | faithfulness | 30 | 0.0045 | [-0.0110, 0.0196] |
| s_to_s - direct_s | completeness | 30 | 0.1362 | [0.0489, 0.2169] |
| s_to_s - direct_s | conciseness | 30 | 0.0137 | [-0.0745, 0.1114] |
| s_to_s - direct_s | faithfulness | 30 | -0.0179 | [-0.0367, 0.0008] |
| l_to_s - s_to_s | completeness | 30 | 0.0079 | [-0.0529, 0.0647] |
| l_to_s - s_to_s | conciseness | 30 | -0.0381 | [-0.1181, 0.0379] |
| l_to_s - s_to_s | faithfulness | 30 | 0.0043 | [-0.0145, 0.0241] |
| l_to_s - direct_s | completeness | 30 | 0.1441 | [0.0339, 0.2447] |
| l_to_s - direct_s | conciseness | 30 | -0.0244 | [-0.1412, 0.0992] |
| l_to_s - direct_s | faithfulness | 30 | -0.0136 | [-0.0310, 0.0020] |
| gold_to_l - gold_to_s | completeness | 30 | 0.0183 | [-0.0497, 0.0821] |
| gold_to_l - gold_to_s | conciseness | 30 | -0.0358 | [-0.0868, 0.0124] |
| gold_to_l - gold_to_s | faithfulness | 30 | 0.0098 | [-0.0121, 0.0334] |
| s_to_l - l_to_l | completeness | 30 | -0.0249 | [-0.0982, 0.0472] |
| s_to_l - l_to_l | conciseness | 30 | 0.0318 | [-0.0165, 0.0743] |
| s_to_l - l_to_l | faithfulness | 30 | -0.0023 | [-0.0241, 0.0193] |

These are diagnostic associations under fact-list intervention. They do not by themselves prove that fact selection explains the entire model-scale gap.
